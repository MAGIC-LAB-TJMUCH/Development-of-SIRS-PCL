
export interface PatientData {
  // --- Administrative ---
  patientId: string;
  imagingModality: 'CE-CT' | 'CE-MRI';
  examinationDate: string;

  // --- Basic Info ---
  age: number;
  gender: 'Male' | 'Female';
  
  // --- Clinical ---
  ca199: number;
  cea: number;
  diabetes: 'Yes' | 'No' | 'NA';
  jaundice: 'Yes' | 'No' | 'nan'; // 'nan' is explicitly used in models
  
  // --- Imaging Dimensions ---
  lesionMaxLongDiameter: number; 
  lesionMaxShortDiameter: number; 
  solidMaxLongDiameter: number; 
  solidMaxShortDiameter: number; 
  muralNoduleLongDiameter: number; 
  muralNoduleShortDiameter: number; 
  mpdMaxDiameter: number; 
  cbdMaxDiameter: number; 
  lymphNodeShortDiameter: number; 
  
  // --- Imaging Features ---
  cystWallThickness: 'Absent cyst wall' | 'Thick-walled' | 'Thin-walled';
  cystWallThicknessUniform: 'Yes' | 'No' | 'Absent cyst wall';
  cystWallEnhancement: 'Absent cyst wall' | 'No enhancement' | 'Delayed enhancement' | 'Early arterial enhancement';
  
  solidEnhancement: 'Absent solid component' | 'No enhancement' | 'Delayed enhancement' | 'Early arterial enhancement';
  
  muralNoduleEnhancement: 'No mural nodule' | 'Enhancement'; 
  muralNoduleEnhancementDetailed: 'No mural nodule' | 'No enhancement' | 'Delayed enhancement' | 'Early arterial enhancement'; 

  intracysticSeptations: 'Absent septations' | 'Thick septations' | 'Thin septations';
  septationsUniform: 'Yes' | 'No' | 'Absent septations';
  septationsEnhancement: 'Absent septations' | 'No enhancement' | 'Delayed enhancement' | 'Early arterial enhancement';
  
  capsule: 'Yes' | 'No';
  
  calcification: 'No calcification' | 'Predominantly peripheral calcification' | 'Predominantly central calcification' | 'Calcification foci visible in both central and peripheral areas' | 'MRI Scan';
  
  // --- Anatomy / Relation ---
  mainPDCommunication: 'Yes' | 'No';
  mpdDilation: 'Yes' | 'No';
  enlargedLymphNodes: 'Yes' | 'No';
  distantMetastasis: 'Yes' | 'No';
  parenchymalAtrophy: 'Yes' | 'No';
  vascularAbutment: 'Yes' | 'No'; 
  
  // --- Classification Specifics ---
  tumorLesion: 'Cystic-solid' | 'Macrocystic' | 'Microcystic' | 'Unilocular';
  lesionLocation: string[]; 
}

export enum DiagnosisClass {
  IPMN = 'IPMN',
  MCN = 'MCN',
  PNET = 'PNET',
  SCN = 'SCN',
  SPN = 'SPN'
}

export enum RiskLevel {
  Low = 'Low Risk',
  Medium = 'Medium Risk',
  High = 'High Risk'
}

export interface FeatureContribution {
  feature: string;
  value: number;
}

export interface GuidelineResult {
  name: string;
  level: 'High Risk' | 'Worrisome' | 'Low Risk';
  strategy: string;
  literatureLink: string;
  findings: string[];
  evaluationLogic: string;
}

export interface PredictionResult {
  diagnosis: {
    class: DiagnosisClass;
    probabilities: Record<DiagnosisClass, number>;
    contributions: FeatureContribution[]; 
  };
  risk?: {
    level: RiskLevel;
    probabilities: Record<RiskLevel, number>;
    modelName: string;
    contributions: FeatureContribution[]; 
  };
  guidelines?: GuidelineResult[];
}