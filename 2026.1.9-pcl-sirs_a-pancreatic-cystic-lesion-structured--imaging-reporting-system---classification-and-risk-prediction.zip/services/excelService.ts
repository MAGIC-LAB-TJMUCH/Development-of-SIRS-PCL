
import * as XLSX from 'xlsx';
import { PatientData, PredictionResult, DiagnosisClass } from '../types';

// Helper to calculate encoded features as seen by the model
const getEncodedFeatures = (data: PatientData) => {
  // Diagnosis Model Params (from predictionService.ts)
  const mean_age = 53.417489; const std_age = 13.838884;
  const mean_lesion = 44.346615; const std_lesion = 24.075763;
  const mean_ca199 = 2.942334; const std_ca199 = 1.471997; 
  const mean_cea = 1.151127; const std_cea = 0.594259;

  const standardize = (val: number, mean: number, std: number, useLog: boolean = false): number => {
    const transformed = useLog ? Math.log(val + 1) : val;
    return (transformed - mean) / std;
  };

  const is = (actual: any, target: any) => actual === target ? 1 : 0;
  const locHeadNeck = data.lesionLocation.some(l => l === 'Pancreatic Head' || l === 'Pancreatic Neck') ? 1 : 0;

  return {
    'Encoded_Age': standardize(data.age, mean_age, std_age),
    'Encoded_LesionSize': standardize(data.lesionMaxLongDiameter, mean_lesion, std_lesion),
    'Encoded_CA199': standardize(data.ca199, mean_ca199, std_ca199, true),
    'Encoded_CEA': standardize(data.cea, mean_cea, std_cea, true),
    'Flag_Female': is(data.gender, 'Female'),
    'Flag_WallUniform_Yes': is(data.cystWallThicknessUniform, 'Yes'),
    'Flag_Tumor_Micro': is(data.tumorLesion, 'Microcystic'),
    'Flag_Tumor_Macro': is(data.tumorLesion, 'Macrocystic'),
    'Flag_SolidEnh_Arterial': is(data.solidEnhancement, 'Early arterial enhancement'),
    'Flag_SolidEnh_Delayed': is(data.solidEnhancement, 'Delayed enhancement'),
    'Flag_ParenAtrophy_Yes': is(data.parenchymalAtrophy, 'Yes'),
    'Flag_MPD_Comm_Yes': is(data.mainPDCommunication, 'Yes'),
    'Flag_MPD_Dil_Yes': is(data.mpdDilation, 'Yes'),
    'Flag_Loc_HeadNeck': locHeadNeck,
    'Flag_Sept_Thin': is(data.intracysticSeptations, 'Thin septations'),
    'Flag_Wall_Thin': is(data.cystWallThickness, 'Thin-walled'),
    'Flag_Wall_Absent': is(data.cystWallThickness, 'Absent cyst wall'),
    'Flag_Capsule_Yes': is(data.capsule, 'Yes'),
    'Flag_Vascular_Yes': is(data.vascularAbutment, 'Yes'),
    'Flag_WallEnh_Delayed': is(data.cystWallEnhancement, 'Delayed enhancement'),
    'Flag_WallEnh_No': is(data.cystWallEnhancement, 'No enhancement')
  };
};

export const exportToExcel = (data: PatientData, result: PredictionResult) => {
  const wb = XLSX.utils.book_new();
  const diagnosisProbs: Record<string, string> = {};
  Object.entries(result.diagnosis.probabilities).forEach(([cls, prob]) => {
    diagnosisProbs[`Prob_${cls}`] = (prob * 100).toFixed(2) + '%';
  });

  const riskProbs: Record<string, string> = {};
  if (result.risk) {
    Object.entries(result.risk.probabilities).forEach(([lvl, prob]) => {
      riskProbs[`RiskProb_${lvl}`] = (prob * 100).toFixed(2) + '%';
    });
  }

  const rowData = {
    'Patient ID': data.patientId,
    ...data,
    'Predicted Diagnosis': result.diagnosis.class,
    ...diagnosisProbs,
    'Risk Model': result.risk ? result.risk.modelName : 'N/A',
    'Predicted Risk Level': result.risk ? result.risk.level : 'N/A',
    ...riskProbs,
    'Timestamp': new Date().toLocaleString()
  };

  const ws = XLSX.utils.json_to_sheet([rowData]);
  XLSX.utils.book_append_sheet(wb, ws, "Clinical Report");
  XLSX.writeFile(wb, `Report_${data.patientId}_${new Date().getTime()}.xlsx`);
};

export const exportBatchToExcel = (batch: {data: PatientData, result: PredictionResult}[]) => {
  const wb = XLSX.utils.book_new();
  const rows = batch.map(item => {
    const { data, result } = item;
    const diagnosisProbs: Record<string, string> = {};
    Object.entries(result.diagnosis.probabilities).forEach(([cls, prob]) => {
      diagnosisProbs[`Prob_${cls}`] = (prob * 100).toFixed(2) + '%';
    });
    const riskProbs: Record<string, string> = {};
    if (result.risk) {
      Object.entries(result.risk.probabilities).forEach(([lvl, prob]) => {
        // Corrected variable name from riskProb to riskProbs
        riskProbs[`RiskProb_${lvl}`] = (prob * 100).toFixed(2) + '%';
      });
    }
    return {
      'Patient ID': data.patientId,
      ...data,
      'Predicted Diagnosis': result.diagnosis.class,
      ...diagnosisProbs,
      'Risk Model': result.risk ? result.risk.modelName : 'N/A',
      'Predicted Risk Level': result.risk ? result.risk.level : 'N/A',
      ...riskProbs,
      'Timestamp': new Date().toLocaleString()
    };
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, "Batch Report");
  XLSX.writeFile(wb, `Batch_Report_${new Date().getTime()}.xlsx`);
};

export const exportEncodedBatchToExcel = (batch: {data: PatientData, result: PredictionResult}[]) => {
  const wb = XLSX.utils.book_new();
  const rows = batch.map(item => {
    const { data, result } = item;
    const encoded = getEncodedFeatures(data);
    return {
      'Patient ID': data.patientId,
      'Raw_Diagnosis': result.diagnosis.class,
      ...encoded,
      ...result.diagnosis.probabilities
    };
  });
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, "Encoded Features");
  XLSX.writeFile(wb, `Encoded_Data_${new Date().getTime()}.xlsx`);
};
