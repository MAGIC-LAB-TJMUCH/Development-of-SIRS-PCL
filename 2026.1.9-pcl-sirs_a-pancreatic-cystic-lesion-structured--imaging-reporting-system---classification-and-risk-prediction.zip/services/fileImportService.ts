
import * as XLSX from 'xlsx';
import { GoogleGenAI, Type } from "@google/genai";
import { PatientData } from '../types';

/**
 * Parses an Excel or CSV file and returns the raw data as JSON.
 */
export const parseFile = async (file: File): Promise<any[]> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        resolve(json);
      } catch (err) {
        reject(err);
      }
    };
    reader.onerror = (err) => reject(err);
    reader.readAsBinaryString(file);
  });
};

/**
 * Helper to normalize clinical categorical values that represent "missing/unknown".
 */
const isMissingLike = (val: any) => {
  if (val === null || typeof val === 'undefined') return true;
  const s = String(val).trim().toLowerCase();
  return s === '' || s === 'none' || s === 'null' || s === 'na' || s === 'n/a' || s === 'unknown' || s === 'unk' || s === 'not available';
};

/**
 * Uses Gemini to map multiple raw rows simultaneously.
 */
export const mapBatchDataWithGemini = async (rawRows: any[]): Promise<Partial<PatientData>[]> => {
  // Upgraded to PRO model for higher accuracy in complex medical extraction
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    You are a high-precision medical data extraction specialist. 
    Task: Map the provided ARRAY of raw clinical data objects into the strictly typed PCL-SIRS schema.
    
    RAW DATA ARRAY: ${JSON.stringify(rawRows)}

    CRITICAL EXTRACTION RULES:
    1. Gender: 'Male' or 'Female'.
    2. Jaundice: 'Yes' (if jaundice, icterus, or yellowing is mentioned), 'No', or 'nan'.
    3. Diabetes: 'Yes', 'No', or 'NA'.
    4. Numeric Extraction & Units: 
       - Standardize to Millimeters (mm). If raw value is in "cm", multiply by 10 (e.g., "2.5cm" -> 25.0).
       - Dimensions like "15x12" -> LD (Long Diameter) = 15, SD (Short Diameter) = 12.
       - If only one value provided (e.g., "15mm"), set LD = 15, SD = 15.
    5. Specific Fields:
       - CA-199 & CEA: Extract raw numeric values.
       - MPD & CBD: Extract numeric diameters.
    6. Imaging Features (Enums):
       - Enhancement: Map to 'No enhancement', 'Delayed enhancement', or 'Early arterial enhancement'. 
         - Rapid/Strong arterial phase -> 'Early arterial enhancement'.
         - Progressive/Late enhancement -> 'Delayed enhancement'.
       - Septations/Wall: Map to 'Thin-walled' (<2mm) or 'Thick-walled' (>=2mm).
       - Tumor Type: Unilocular, Macrocystic (cysts >=2cm), Microcystic (cysts <2cm), or Cystic-solid (>50% solid).
    7. Lesion Location: Map to an ARRAY containing: 'Pancreatic Head', 'Pancreatic Neck', 'Pancreatic Body', 'Pancreatic Tail'.
    8. PD Communication: "Communication with MPD" -> 'Yes'.
    9. Defaulting: If a feature is not mentioned, use clinical common sense to map to the safest negative value (e.g., 'No calcification', 'No' for metastasis).

    Return ONLY a JSON array of objects.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', // High-precision model
      contents: [{ parts: [{ text: prompt }] }],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              patientId: { type: Type.STRING },
              imagingModality: { type: Type.STRING },
              examinationDate: { type: Type.STRING },
              age: { type: Type.NUMBER },
              gender: { type: Type.STRING },
              ca199: { type: Type.NUMBER },
              cea: { type: Type.NUMBER },
              diabetes: { type: Type.STRING },
              jaundice: { type: Type.STRING },
              lesionMaxLongDiameter: { type: Type.NUMBER },
              lesionMaxShortDiameter: { type: Type.NUMBER },
              solidMaxLongDiameter: { type: Type.NUMBER },
              solidMaxShortDiameter: { type: Type.NUMBER },
              muralNoduleLongDiameter: { type: Type.NUMBER },
              muralNoduleShortDiameter: { type: Type.NUMBER },
              mpdMaxDiameter: { type: Type.NUMBER },
              cbdMaxDiameter: { type: Type.NUMBER },
              lymphNodeShortDiameter: { type: Type.NUMBER },
              cystWallThickness: { type: Type.STRING },
              cystWallThicknessUniform: { type: Type.STRING },
              cystWallEnhancement: { type: Type.STRING },
              solidEnhancement: { type: Type.STRING },
              muralNoduleEnhancementDetailed: { type: Type.STRING },
              intracysticSeptations: { type: Type.STRING },
              septationsUniform: { type: Type.STRING },
              septationsEnhancement: { type: Type.STRING },
              capsule: { type: Type.STRING },
              calcification: { type: Type.STRING },
              mainPDCommunication: { type: Type.STRING },
              mpdDilation: { type: Type.STRING },
              enlargedLymphNodes: { type: Type.STRING },
              distantMetastasis: { type: Type.STRING },
              parenchymalAtrophy: { type: Type.STRING },
              vascularAbutment: { type: Type.STRING },
              tumorLesion: { type: Type.STRING },
              lesionLocation: { 
                type: Type.ARRAY,
                items: { type: Type.STRING }
              }
            }
          }
        }
      }
    });

    const results = JSON.parse(response.text || '[]') as any[];

    return results.map(result => {
      if (isMissingLike(result.diabetes)) result.diabetes = 'NA';
      if (isMissingLike(result.jaundice)) result.jaundice = 'nan';
      if (!Array.isArray(result.lesionLocation)) result.lesionLocation = [];
      if (!result.examinationDate) result.examinationDate = new Date().toISOString().split('T')[0];
      return result;
    });
  } catch (error) {
    console.error("Batch Mapping Error:", error);
    return rawRows.map(() => ({ lesionLocation: [], examinationDate: new Date().toISOString().split('T')[0] }));
  }
};