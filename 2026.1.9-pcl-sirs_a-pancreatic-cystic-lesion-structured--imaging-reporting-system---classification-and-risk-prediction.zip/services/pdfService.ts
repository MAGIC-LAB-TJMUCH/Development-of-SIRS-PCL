
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { PatientData, PredictionResult, FeatureContribution, RiskLevel, GuidelineResult, DiagnosisClass } from '../types';

const COLORS = {
  MEDICAL_900: [12, 74, 110],  // #0c4a6e
  MEDICAL_800: [7, 89, 133],   // #075985
  MEDICAL_600: [2, 132, 199],  // #0284c7 (Positive/Supports)
  MEDICAL_50: [240, 249, 255],  // #f0f9ff
  SUCCESS: [16, 185, 129],     // #10b981 (Green)
  WARNING: [245, 158, 11],     // #f59e0b (Orange)
  ORANGE_500: [249, 115, 22],  // #f97316 (Negative/Opposes)
  DANGER: [239, 68, 68],       // #ef4444 (Red)
  TEXT_MAIN: [31, 41, 55],     // Gray 800
  TEXT_MUTED: [107, 114, 128], // Gray 500
  BORDER: [229, 231, 235],     // Gray 200
  GRID: [240, 240, 240]        // Very light gray
};

const DIAG_COLOR_MAP: Record<string, number[]> = {
  [DiagnosisClass.IPMN]: [14, 165, 233],
  [DiagnosisClass.MCN]: [249, 115, 22],
  [DiagnosisClass.PNET]: [239, 68, 68],
  [DiagnosisClass.SCN]: [16, 185, 129],
  [DiagnosisClass.SPN]: [139, 92, 246]
};

const DIAG_PDF_BG_COLORS: Record<string, number[]> = {
  [DiagnosisClass.IPMN]: [3, 105, 161],
  [DiagnosisClass.MCN]: [234, 88, 12],
  [DiagnosisClass.SCN]: [4, 120, 87],
  [DiagnosisClass.PNET]: [185, 28, 28],
  [DiagnosisClass.SPN]: [109, 40, 217]
};

const drawDonutChart = (doc: jsPDF, x: number, y: number, radius: number, probs: Record<string, number>, colorMap: Record<string, number[]>) => {
  let startAngle = -Math.PI / 2;
  const entries = Object.entries(probs).sort((a, b) => b[1] - a[1]);
  entries.forEach(([name, val], i) => {
    if (val < 0.005) return;
    const sliceAngle = val * 2 * Math.PI;
    const endAngle = startAngle + sliceAngle;
    const color = colorMap[name] || [148, 163, 184];
    doc.setFillColor(color[0], color[1], color[2]);
    doc.moveTo(x, y);
    const segments = 60;
    for (let s = 0; s <= segments; s++) {
      const angle = startAngle + (sliceAngle * (s / segments));
      doc.lineTo(x + radius * Math.cos(angle), y + radius * Math.sin(angle));
    }
    doc.fill();
    startAngle = endAngle;
  });
  doc.setFillColor(255, 255, 255);
  doc.circle(x, y, radius * 0.7, 'F');
};

const drawDistributionBars = (doc: jsPDF, x: number, y: number, probs: Record<string, number>, colorMap: Record<string, number[]>) => {
  const entries = Object.entries(probs).sort((a, b) => b[1] - a[1]);
  entries.forEach(([name, val], i) => {
    const ly = y + (i * 6.5);
    const color = colorMap[name] || [148, 163, 184];
    
    // Icon
    doc.setFillColor(color[0], color[1], color[2]);
    doc.roundedRect(x, ly + 0.5, 2.2, 2.2, 0.3, 0.3, 'F');
    
    // Label
    doc.setFontSize(7.5);
    doc.setTextColor(COLORS.TEXT_MAIN[0], COLORS.TEXT_MAIN[1], COLORS.TEXT_MAIN[2]);
    doc.setFont("helvetica", "normal");
    doc.text(name, x + 3.5, ly + 2.5);
    
    // Prob Text
    const probStr = `${(val * 100).toFixed(1)}%`;
    doc.setFont("helvetica", "bold");
    doc.text(probStr, x + 38, ly + 2.5, { align: 'right' });
    
    // Mini Bar
    doc.setFillColor(245, 245, 245);
    doc.roundedRect(x + 40, ly + 0.5, 25, 2.2, 0.4, 0.4, 'F');
    doc.setFillColor(color[0], color[1], color[2]);
    const barWidth = Math.max(0.4, 25 * val);
    doc.roundedRect(x + 40, ly + 0.5, barWidth, 2.2, 0.4, 0.4, 'F');
  });
};

const drawShapBars = (doc: jsPDF, startY: number, contributions: FeatureContribution[], title: string): number => {
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 20;
  let y = startY;

  doc.setFillColor(COLORS.MEDICAL_600[0], COLORS.MEDICAL_600[1], COLORS.MEDICAL_600[2]);
  doc.rect(margin, y - 5, 1.2, 7, 'F');
  doc.setFontSize(11);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(COLORS.TEXT_MAIN[0], COLORS.TEXT_MAIN[1], COLORS.TEXT_MAIN[2]);
  doc.text(title, margin + 5, y);
  y += 10;

  const labelW = 55; 
  const chartAreaW = pageWidth - (margin * 2) - labelW;
  const centerAxisX = margin + labelW + (chartAreaW / 2);
  const maxBarW = (chartAreaW / 2) - 15;
  const maxChartHeight = pageHeight - y - 45;
  const items = contributions.filter(c => Math.abs(c.value) > 0.0001); 
  let barH = 5.5;
  let gap = 2.5;
  const totalNeeded = items.length * (barH + gap);
  if (totalNeeded > maxChartHeight) {
    const availablePerItem = maxChartHeight / items.length;
    barH = availablePerItem * 0.7;
    gap = availablePerItem * 0.3;
  }
  const totalChartHeight = items.length * (barH + gap);
  const maxAbsVal = Math.max(...items.map(c => Math.abs(c.value))) || 1;

  doc.setGState(new (doc as any).GState({ opacity: 0.25 }));
  doc.setDrawColor(180, 180, 180);
  doc.setLineDashPattern([1, 1], 0);
  [-1, -0.75, -0.5, -0.25, 0.25, 0.5, 0.75, 1].forEach(factor => {
    const offsetX = factor * maxBarW;
    doc.line(centerAxisX + offsetX, y - 2, centerAxisX + offsetX, y + totalChartHeight);
  });
  doc.setLineDashPattern([], 0);
  doc.setGState(new (doc as any).GState({ opacity: 1.0 }));
  doc.setDrawColor(100, 100, 100);
  doc.setLineWidth(0.4);
  doc.line(centerAxisX, y - 2, centerAxisX, y + totalChartHeight);

  items.forEach((contrib, i) => {
    doc.setDrawColor(245, 245, 245);
    doc.line(margin, y + barH + (gap/2), pageWidth - margin, y + barH + (gap/2));
    doc.setFontSize(Math.min(7.5, barH + 1.2));
    doc.setFont("helvetica", "normal");
    doc.setTextColor(COLORS.TEXT_MAIN[0], COLORS.TEXT_MAIN[1], COLORS.TEXT_MAIN[2]);
    doc.text(contrib.feature, margin, y + (barH * 0.8));
    const scaledWidth = (Math.abs(contrib.value) / maxAbsVal) * maxBarW;
    if (contrib.value >= 0) {
      doc.setFillColor(COLORS.MEDICAL_600[0], COLORS.MEDICAL_600[1], COLORS.MEDICAL_600[2]);
      doc.roundedRect(centerAxisX, y, Math.max(scaledWidth, 0.4), barH, 0.3, 0.3, 'F');
      doc.setFontSize(Math.min(6, barH));
      doc.setTextColor(COLORS.TEXT_MUTED[0], COLORS.TEXT_MUTED[1], COLORS.TEXT_MUTED[2]);
      doc.text(contrib.value.toFixed(4), centerAxisX + scaledWidth + 1.5, y + (barH * 0.8));
    } else {
      doc.setFillColor(COLORS.ORANGE_500[0], COLORS.ORANGE_500[1], COLORS.ORANGE_500[2]);
      doc.roundedRect(centerAxisX - scaledWidth, y, Math.max(scaledWidth, 0.4), barH, 0.3, 0.3, 'F');
      doc.setFontSize(Math.min(6, barH));
      doc.setTextColor(COLORS.TEXT_MUTED[0], COLORS.TEXT_MUTED[1], COLORS.TEXT_MUTED[2]);
      const valStr = contrib.value.toFixed(4);
      const textWidth = doc.getTextWidth(valStr);
      doc.text(valStr, centerAxisX - scaledWidth - textWidth - 1.5, y + (barH * 0.8));
    }
    y += barH + gap;
  });
  y += 12;
  const negLegendX = centerAxisX - maxBarW;
  doc.setFillColor(COLORS.ORANGE_500[0], COLORS.ORANGE_500[1], COLORS.ORANGE_500[2]);
  doc.rect(negLegendX, y, 3, 3, 'F');
  doc.setFontSize(8);
  doc.setTextColor(COLORS.TEXT_MUTED[0], COLORS.TEXT_MUTED[1], COLORS.TEXT_MUTED[2]);
  doc.text("Opposes Prediction", negLegendX + 5, y + 2.5);
  const posLegendX = centerAxisX + 5;
  doc.setFillColor(COLORS.MEDICAL_600[0], COLORS.MEDICAL_600[1], COLORS.MEDICAL_600[2]);
  doc.rect(posLegendX, y, 3, 3, 'F');
  doc.text("Supports Prediction", posLegendX + 5, y + 2.5);
  return y + 10;
};

const drawPageHeader = (doc: jsPDF, sectionTitle: string) => {
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  doc.setFontSize(11);
  doc.setTextColor(COLORS.MEDICAL_800[0], COLORS.MEDICAL_800[1], COLORS.MEDICAL_800[2]);
  doc.setFont("helvetica", "bold");
  doc.text("PCL-SIRS Pathological classification & risk stratification", margin, 15);
  doc.setFontSize(16);
  doc.setTextColor(COLORS.TEXT_MAIN[0], COLORS.TEXT_MAIN[1], COLORS.TEXT_MAIN[2]);
  doc.setFont("helvetica", "bold");
  doc.text(sectionTitle, margin, 28);
  doc.setDrawColor(COLORS.BORDER[0], COLORS.BORDER[1], COLORS.BORDER[2]);
  doc.line(margin, 32, pageWidth - margin, 32);
};

const generateClinicalAppendix = (doc: jsPDF, data: PatientData) => {
  doc.addPage();
  drawPageHeader(doc, "Clinical Parameters Appendix");
  
  const margin = 20;
  const tableData = [
    ["Parameter Group", "Feature", "Input Value"],
    ["Administrative", "Imaging Modality", data.imagingModality],
    ["Administrative", "Examination Date", data.examinationDate],
    ["Basic Info", "Age", `${data.age} years`],
    ["Basic Info", "Gender", data.gender],
    ["Clinical", "CA-199", `${data.ca199} U/mL`],
    ["Clinical", "CEA", `${data.cea} ng/mL`],
    ["Clinical", "Diabetes", data.diabetes],
    ["Clinical", "Jaundice", data.jaundice],
    ["Lesion Dimensions", "Lesion (LD x SD)", `${data.lesionMaxLongDiameter} x ${data.lesionMaxShortDiameter} mm`],
    ["Lesion Dimensions", "Solid (LD x SD)", `${data.solidMaxLongDiameter} x ${data.solidMaxShortDiameter} mm`],
    ["Lesion Dimensions", "Mural Nodule (LD x SD)", `${data.muralNoduleLongDiameter} x ${data.muralNoduleShortDiameter} mm`],
    ["Lesion Dimensions", "MPD / CBD Diameter", `${data.mpdMaxDiameter} / ${data.cbdMaxDiameter} mm`],
    ["Imaging Features", "Tumor Lesion Type", data.tumorLesion],
    ["Imaging Features", "Cyst Wall Thickness", data.cystWallThickness],
    ["Imaging Features", "Wall Uniformity", data.cystWallThicknessUniform],
    ["Imaging Features", "Wall Enhancement", data.cystWallEnhancement],
    ["Imaging Features", "Solid Enhancement", data.solidEnhancement],
    ["Imaging Features", "Mural Nodule Enh.", data.muralNoduleEnhancementDetailed],
    ["Imaging Features", "Septations", data.intracysticSeptations],
    ["Imaging Features", "Septa Uniformity", data.septationsUniform],
    ["Anatomy", "Capsule", data.capsule],
    ["Anatomy", "Calcification", data.calcification],
    ["Anatomy", "PD Communication", data.mainPDCommunication],
    ["Anatomy", "Vascular Abutment", data.vascularAbutment],
    ["Anatomy", "Parenchymal Atrophy", data.parenchymalAtrophy],
    ["Anatomy", "Lymph Nodes / Metastasis", `${data.enlargedLymphNodes} / ${data.distantMetastasis}`]
  ];

  (doc as any).autoTable({
    startY: 40,
    head: [tableData[0]],
    body: tableData.slice(1),
    theme: 'grid',
    headStyles: { 
      fillColor: COLORS.MEDICAL_900, 
      textColor: [255, 255, 255], 
      fontSize: 10, 
      fontStyle: 'bold',
      halign: 'left'
    },
    bodyStyles: { fontSize: 8.5, textColor: COLORS.TEXT_MAIN },
    alternateRowStyles: { fillColor: [250, 250, 252] },
    columnStyles: {
      0: { fontStyle: 'bold', fillColor: [245, 247, 250], width: 40 },
      1: { width: 60 },
      2: { fontStyle: 'bold', textColor: COLORS.MEDICAL_800 }
    },
    margin: { left: margin, right: margin }
  });
};

const generateCaseReport = (doc: jsPDF, data: PatientData, result: PredictionResult, isFirst: boolean) => {
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  
  if (!isFirst) doc.addPage();
  
  // P1: CLASSIFICATION
  drawPageHeader(doc, " Pathological Classification");
  let currentY = 42;
  doc.setFillColor(COLORS.MEDICAL_50[0], COLORS.MEDICAL_50[1], COLORS.MEDICAL_50[2]);
  doc.roundedRect(margin, currentY, pageWidth - (margin * 2), 16, 1, 1, 'F');
  doc.setFontSize(9);
  doc.setTextColor(COLORS.TEXT_MUTED[0], COLORS.TEXT_MUTED[1], COLORS.TEXT_MUTED[2]);
  doc.text("Patient ID:", margin + 5, currentY + 7);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(COLORS.MEDICAL_800[0], COLORS.MEDICAL_800[1], COLORS.MEDICAL_800[2]);
  doc.text(data.patientId || 'Case', margin + 25, currentY + 7);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(COLORS.TEXT_MUTED[0], COLORS.TEXT_MUTED[1], COLORS.TEXT_MUTED[2]);
  doc.text(`Age ${data.age}, ${data.gender} | CA-199: ${data.ca199} U/mL | Date: ${data.examinationDate}`, margin + 5, currentY + 13);

  currentY += 22;
  const diagBgColor = DIAG_PDF_BG_COLORS[result.diagnosis.class] || COLORS.MEDICAL_800;
  doc.setFillColor(diagBgColor[0], diagBgColor[1], diagBgColor[2]);
  doc.roundedRect(margin, currentY, 70, 30, 2, 2, 'F');
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.setFont("helvetica", "normal");
  doc.text("CLASSIFICATION", margin + 6, currentY + 8);
  doc.setFontSize(22);
  doc.setFont("helvetica", "bold");
  doc.text(result.diagnosis.class, margin + 6, currentY + 18);
  doc.setFontSize(8.5);
  doc.text(`Confidence: ${(result.diagnosis.probabilities[result.diagnosis.class] * 100).toFixed(1)}%`, margin + 6, currentY + 24);
  
  doc.setFillColor(255, 255, 255, 0.25);
  doc.roundedRect(margin + 6, currentY + 26, 58, 2, 0.5, 0.5, 'F');
  doc.setFillColor(255, 255, 255, 0.95);
  doc.roundedRect(margin + 6, currentY + 26, 58 * result.diagnosis.probabilities[result.diagnosis.class], 2, 0.5, 0.5, 'F');

  // Optimized Layout: x = margin + 85 (Donut), x = margin + 110 (Legend)
  drawDonutChart(doc, margin + 85, currentY + 15, 14, result.diagnosis.probabilities, DIAG_COLOR_MAP);
  drawDistributionBars(doc, margin + 110, currentY + 1, result.diagnosis.probabilities, DIAG_COLOR_MAP);
  
  currentY += 45;
  drawShapBars(doc, currentY, result.diagnosis.contributions, "Diagnostic Drivers (SHAP Analysis)");

  // P2: RISK
  if (result.risk) {
    doc.addPage();
    drawPageHeader(doc, "Risk Stratification");
    currentY = 42;
    const riskLevelColors: Record<string, number[]> = {
      [RiskLevel.Low]: COLORS.SUCCESS,
      [RiskLevel.Medium]: COLORS.WARNING,
      [RiskLevel.High]: COLORS.DANGER
    };
    const riskHeaderColors: Record<string, number[]> = {
      [RiskLevel.Low]: [21, 128, 61],
      [RiskLevel.Medium]: [180, 83, 9],
      [RiskLevel.High]: [153, 27, 27]
    };
    const rBg = riskHeaderColors[result.risk.level] || [100, 100, 100]; 
    doc.setFillColor(rBg[0], rBg[1], rBg[2]);
    doc.roundedRect(margin, currentY, 70, 30, 2, 2, 'F');
    doc.setFontSize(9);
    doc.setTextColor(255, 255, 255);
    doc.text(result.risk.modelName.toUpperCase(), margin + 6, currentY + 8);
    doc.setFontSize(22);
    doc.setFont("helvetica", "bold");
    doc.text(result.risk.level, margin + 6, currentY + 18);
    doc.setFontSize(8.5);
    doc.text(`Probability: ${(result.risk.probabilities[result.risk.level] * 100).toFixed(1)}%`, margin + 6, currentY + 24);
    doc.setFillColor(255, 255, 255, 0.25);
    doc.roundedRect(margin + 6, currentY + 26, 58, 2, 0.5, 0.5, 'F');
    doc.setFillColor(255, 255, 255, 0.95);
    doc.roundedRect(margin + 6, currentY + 26, 58 * result.risk.probabilities[result.risk.level], 2, 0.5, 0.5, 'F');
    
    // Optimized Layout
    drawDonutChart(doc, margin + 85, currentY + 15, 14, result.risk.probabilities, riskLevelColors);
    drawDistributionBars(doc, margin + 110, currentY + 3, result.risk.probabilities, riskLevelColors);
    
    currentY += 45;
    drawShapBars(doc, currentY, result.risk.contributions, "Risk Factor Weightings (SHAP Analysis)");
  }

  // P3: GUIDELINES
  if (result.guidelines && result.guidelines.length > 0) {
    doc.addPage();
    drawPageHeader(doc, "Guideline Evaluation");
    currentY = 40;
    result.guidelines.forEach((g) => {
      const riskLevelColors: Record<string, number[]> = {
        'Low Risk': COLORS.SUCCESS,
        'Worrisome': COLORS.WARNING,
        'High Risk': COLORS.DANGER
      };
      const levelColor = riskLevelColors[g.level] || [100, 100, 100];
      const cardHeight = 35;
      doc.setFillColor(252, 252, 252);
      doc.setDrawColor(COLORS.BORDER[0], COLORS.BORDER[1], COLORS.BORDER[2]);
      doc.rect(margin, currentY, pageWidth - (margin * 2), cardHeight, 'FD');
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(COLORS.TEXT_MAIN[0], COLORS.TEXT_MAIN[1], COLORS.TEXT_MAIN[2]);
      doc.text(g.name, margin + 4, currentY + 6);
      doc.setFillColor(levelColor[0], levelColor[1], levelColor[2]);
      doc.roundedRect(pageWidth - margin - 22, currentY + 3, 18, 5, 0.8, 0.8, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(6.5);
      doc.text(g.level.toUpperCase(), pageWidth - margin - 13, currentY + 6.5, { align: 'center' });
      doc.setTextColor(COLORS.TEXT_MAIN[0], COLORS.TEXT_MAIN[1], COLORS.TEXT_MAIN[2]);
      doc.setFontSize(7.5);
      doc.setFont("helvetica", "bold");
      doc.text("Findings: ", margin + 4, currentY + 12);
      doc.setFont("helvetica", "normal");
      doc.text(g.findings.join(", "), margin + 18, currentY + 12, { maxWidth: pageWidth - margin * 2 - 25 });
      doc.setFillColor(COLORS.MEDICAL_50[0], COLORS.MEDICAL_50[1], COLORS.MEDICAL_50[2]);
      doc.rect(margin + 2, currentY + 19, pageWidth - (margin * 2) - 4, 11, 'F');
      doc.setFont("helvetica", "bold");
      doc.setTextColor(COLORS.MEDICAL_800[0], COLORS.MEDICAL_800[1], COLORS.MEDICAL_800[2]);
      doc.text("Strategy: ", margin + 6, currentY + 26);
      doc.setFont("helvetica", "normal");
      doc.text(g.strategy, margin + 22, currentY + 26, { maxWidth: pageWidth - margin * 2 - 30 });
      currentY += cardHeight + 4;
    });
  }

  // P4: CLINICAL APPENDIX
  generateClinicalAppendix(doc, data);
};

const addFooters = (doc: jsPDF, timestamp: string) => {
  const pageHeight = doc.internal.pageSize.getHeight();
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;
  const totalPages = (doc as any).internal.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(8);
    doc.setTextColor(COLORS.TEXT_MUTED[0], COLORS.TEXT_MUTED[1], COLORS.TEXT_MUTED[2]);
    doc.text(`PCL-SIRS pathological classification & risk stratification | Page ${i} of ${totalPages}`, margin, pageHeight - 10);
    doc.text(`Generated: ${timestamp}`, pageWidth - margin, pageHeight - 10, { align: 'right' });
  }
};

export const exportToPDF = (data: PatientData, result: PredictionResult) => {
  const doc = new jsPDF();
  const timestamp = new Date().toLocaleString();
  generateCaseReport(doc, data, result, true);
  addFooters(doc, timestamp);
  doc.save(`PCL_SIRS_Report_${data.patientId || 'Case'}.pdf`);
};

export const exportBatchToPDF = (batch: {data: PatientData, result: PredictionResult}[]) => {
  const doc = new jsPDF();
  const timestamp = new Date().toLocaleString();
  batch.forEach((item, index) => {
    generateCaseReport(doc, item.data, item.result, index === 0);
  });
  addFooters(doc, timestamp);
  doc.save(`PCL_SIRS_Batch_Reports.pdf`);
};