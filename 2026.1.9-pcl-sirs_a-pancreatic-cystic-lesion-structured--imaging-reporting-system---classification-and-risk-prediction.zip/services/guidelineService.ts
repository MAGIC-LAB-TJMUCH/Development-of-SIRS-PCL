
import { PatientData, GuidelineResult } from '../types';

export const evaluateGuidelines = (data: PatientData): GuidelineResult[] => {
  const results: GuidelineResult[] = [];

  // Helper: Checks for enhancing mural nodules based on detailed enhancement patterns
  const isEnhancingNodule = (data: PatientData) => 
    data.muralNoduleEnhancementDetailed !== 'No mural nodule' && 
    data.muralNoduleEnhancementDetailed !== 'No enhancement';

  // Helper: HRS Nodule definition (Enhancing AND >= 5mm)
  const hasHighRiskNodule = (data: PatientData) => 
    data.muralNoduleLongDiameter >= 5 && isEnhancingNodule(data);

  // --- 1. 2024 Kyoto Consensus (IPMN) ---
  const kyotoFindings: string[] = [];
  let kyotoLevel: 'High Risk' | 'Worrisome' | 'Low Risk' = 'Low Risk';

  // High-Risk Stigmata (HRS) - Indicators removed from analysis: Cytology
  if (data.jaundice === 'Yes') kyotoFindings.push("Jaundice (cyst-related)");
  if (hasHighRiskNodule(data) || data.solidMaxLongDiameter > 0) {
    kyotoFindings.push("Enhancing Mural Nodule >= 5mm or Solid Component");
  }
  if (data.mpdMaxDiameter >= 10) kyotoFindings.push("Main Pancreatic Duct (MPD) >= 10mm");

  if (kyotoFindings.length > 0) {
    kyotoLevel = 'High Risk';
  } else {
    // Worrisome Features (WF) / Intermediate Risk - Indicators removed from analysis: Pancreatitis, Growth
    if (data.lesionMaxLongDiameter >= 30) kyotoFindings.push("Cyst Diameter >= 30mm");
    if (data.muralNoduleLongDiameter > 0 && data.muralNoduleLongDiameter < 5) {
      kyotoFindings.push("Mural Nodule < 5mm (regardless of enhancement)");
    }
    if (data.mpdMaxDiameter >= 5 && data.mpdMaxDiameter < 10) kyotoFindings.push("MPD 5-9mm");
    if (data.cystWallThickness === 'Thick-walled' || (data.cystWallEnhancement !== 'No enhancement' && data.cystWallEnhancement !== 'Absent cyst wall')) {
      kyotoFindings.push("Cyst Wall Thickening/Enhancement");
    }
    if (data.ca199 > 37) kyotoFindings.push("CA19-9 Elevated (>37 U/mL)");

    if (kyotoFindings.length > 0) kyotoLevel = 'Worrisome';
  }

  results.push({
    name: "2024 Kyoto Consensus",
    level: kyotoLevel,
    findings: kyotoFindings.length > 0 ? kyotoFindings : ["No high-risk stigmata or worrisome features identified"],
    strategy: kyotoLevel === 'High Risk' ? "Surgical resection is strongly recommended." : kyotoLevel === 'Worrisome' ? "EUS evaluation or close surveillance (3-6 months) is recommended." : "Routine surveillance based on size stability.",
    literatureLink: "https://doi.org/10.1016/j.pan.2024.01.001",
    evaluationLogic: "High Risk (HRS): Jaundice, Enhancing Nodule >=5mm/Solid, MPD >=10mm. Intermediate (WF): Size >=30mm, Nodule <5mm, MPD 5-9mm, Wall thickening, CA19-9."
  });

  // --- 2. 2018 European Evidence-based Guidelines ---
  const eusFindings: string[] = [];
  let eusLevel: 'High Risk' | 'Worrisome' | 'Low Risk' = 'Low Risk';

  // Absolute Indications (High Risk) - Indicator removed: Cytology
  const hasAbsoluteIndication = 
    data.jaundice === 'Yes' || 
    hasHighRiskNodule(data) || 
    data.solidMaxLongDiameter > 0 || 
    data.mpdMaxDiameter >= 10;

  if (hasAbsoluteIndication) {
    eusLevel = 'High Risk';
    if (data.jaundice === 'Yes') eusFindings.push("Jaundice");
    if (hasHighRiskNodule(data) || data.solidMaxLongDiameter > 0) eusFindings.push("Enhancing Mural Nodule >= 5mm or Solid Component");
    if (data.mpdMaxDiameter >= 10) eusFindings.push("MPD >= 10mm");
  } else {
    // Relative Indications (Worrisome) - Indicators removed: Growth, Pancreatitis
    if (data.lesionMaxLongDiameter >= 40) eusFindings.push("Cyst Diameter >= 40mm");
    if (data.mpdMaxDiameter >= 5 && data.mpdMaxDiameter < 10) eusFindings.push("MPD 5-9mm");
    if (data.ca199 > 37) eusFindings.push("Elevated CA19-9");
    if (data.diabetes === 'Yes') eusFindings.push("New-onset Diabetes");

    if (eusFindings.length > 0) eusLevel = 'Worrisome';
  }

  results.push({
    name: "2018 European Guidelines",
    level: eusLevel,
    findings: eusFindings.length > 0 ? eusFindings : ["No absolute or relative indications for surgery identified"],
    strategy: eusLevel === 'High Risk' ? "Absolute indication for surgery." : eusLevel === 'Worrisome' ? "Relative indication for surgery; multidisciplinary evaluation required." : "Safe for surveillance.",
    literatureLink: "https://doi.org/10.1136/gutjnl-2018-316027",
    evaluationLogic: "Absolute: Jaundice, Enhancing Nodule >=5mm/Solid, MPD >=10mm. Relative: Size >=40mm, MPD 5-9mm, CA19-9, Diabetes."
  });

  // --- 3. 2023 Hong Kong Consensus ---
  const hkFindings: string[] = [];
  let hkLevel: 'High Risk' | 'Worrisome' | 'Low Risk' = 'Low Risk';

  // Absolute Indications (High Risk) - Indicator removed: Cytology
  const isHKHighRisk = 
    data.jaundice === 'Yes' || 
    hasHighRiskNodule(data) || 
    data.solidMaxLongDiameter > 0 || 
    data.mpdMaxDiameter >= 10;

  if (isHKHighRisk) {
    hkLevel = 'High Risk';
    if (data.jaundice === 'Yes') hkFindings.push("Jaundice");
    if (hasHighRiskNodule(data) || data.solidMaxLongDiameter > 0) hkFindings.push("Enhancing Mural Nodule (>=5mm) or Solid Component");
    if (data.mpdMaxDiameter >= 10) hkFindings.push("MPD >= 10mm");
  } else {
    // Worrisome Features (Middle Risk) - Indicators removed: Growth, Pancreatitis
    if (data.lesionMaxLongDiameter >= 30) hkFindings.push("Cyst size >= 30mm");
    if (data.muralNoduleLongDiameter > 0 && data.muralNoduleLongDiameter < 5) hkFindings.push("Mural Nodule < 5mm");
    if (data.mpdMaxDiameter >= 5 && data.mpdMaxDiameter < 10) hkFindings.push("MPD 5-9mm");
    if (data.diabetes === 'Yes') hkFindings.push("New-onset Diabetes");
    if (data.ca199 > 37) hkFindings.push("Elevated CA19-9 (>37 U/mL)");

    if (hkFindings.length > 0) hkLevel = 'Worrisome';
  }

  results.push({
    name: "2023 Hong Kong Consensus",
    level: hkLevel,
    findings: hkFindings.length > 0 ? hkFindings : ["No absolute indications or worrisome features identified"],
    strategy: hkLevel === 'High Risk' ? "Surgical resection is the primary recommendation." : hkLevel === 'Worrisome' ? "Close monitoring or EUS-FNA recommended." : "Routine surveillance.",
    literatureLink: "https://doi.org/10.1016/j.pan.2023.06.002",
    evaluationLogic: "Absolute: Jaundice, Enhancing Nodule >=5mm/Solid, MPD >=10mm. Worrisome: Size >=30mm, Nodule <5mm, MPD 5-9mm, Diabetes, CA19-9."
  });

  // --- 4. 2018 ACG Guidelines ---
  const acgFindings: string[] = [];
  let acgLevel: 'High Risk' | 'Worrisome' | 'Low Risk' = 'Low Risk';

  // ACG 2018: "Intermediate Risk" - Indicators removed: Growth, Cytology
  const isACGIntermediate = 
    data.jaundice === 'Yes' || 
    data.solidMaxLongDiameter > 0 || 
    data.muralNoduleLongDiameter > 0 ||
    data.mpdMaxDiameter > 5 ||
    data.lesionMaxLongDiameter >= 30 ||
    data.ca199 > 37;

  if (isACGIntermediate) {
    acgLevel = 'Worrisome';
    if (data.jaundice === 'Yes') acgFindings.push("Jaundice");
    if (data.solidMaxLongDiameter > 0 || data.muralNoduleLongDiameter > 0) acgFindings.push("Solid Component or Mural Nodule");
    if (data.mpdMaxDiameter > 5) acgFindings.push("MPD > 5mm");
    if (data.lesionMaxLongDiameter >= 30) acgFindings.push("Cyst Diameter >= 30mm");
    if (data.ca199 > 37) acgFindings.push("Elevated CA19-9 (>37 U/mL)");
  }

  results.push({
    name: "2018 ACG Guidelines",
    level: acgLevel,
    findings: acgFindings.length > 0 ? acgFindings : ["Cyst < 30mm and no intermediate-risk features identified"],
    strategy: acgLevel === 'Worrisome' ? "EUS-FNA or shorter follow-up intervals recommended for intermediate features." : "Surveillance based on cyst size and stability.",
    literatureLink: "https://doi.org/10.1038/s41395-018-0008-5",
    evaluationLogic: "Intermediate Risk: Jaundice, Solid/Nodule, MPD >5mm, Cyst >=30mm, CA19-9."
  });

  return results;
};