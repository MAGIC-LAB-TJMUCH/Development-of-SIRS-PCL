
import { PatientData, DiagnosisClass, RiskLevel, PredictionResult, FeatureContribution } from '../types';
import { evaluateGuidelines } from './guidelineService';

// --- Helper Functions ---

const standardize = (val: number, mean: number, std: number, useLog: boolean = false): number => {
  const transformed = useLog ? Math.log(val + 1) : val;
  return (transformed - mean) / std;
};

const softmax = (etas: number[]): number[] => {
  const maxEta = Math.max(...etas); // Numerical stability
  const expEtas = etas.map(eta => Math.exp(eta - maxEta));
  const sumExp = expEtas.reduce((a, b) => a + b, 0);
  return expEtas.map(e => e / sumExp);
};

const getTopContributions = (contributions: Record<string, number>): FeatureContribution[] => {
  return Object.entries(contributions)
    .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
    .map(([feature, value]) => ({ feature, value }));
};

const is = (actual: any, target: any) => actual === target ? 1 : 0;

// --- Model 3: 5-Class Diagnosis (IPMN, MCN, PNET, SCN, SPN) ---
const predictDiagnosis = (data: PatientData) => {
  // Params from Standardization_Parameters.xlsx
  const mean_age = 53.417489; const std_age = 13.838884;
  const mean_lesion = 44.346615; const std_lesion = 24.075763;
  // 'Long diameter of solid component' is present in standardization params but NOT in coefficients, so it's removed.
  const mean_ca199 = 2.94233377; const std_ca199 = 1.47199714; // Log scale implied by usage context
  const mean_cea = 1.15112705; const std_cea = 0.59425943; // Log scale implied by usage context

  const X_Age = standardize(data.age, mean_age, std_age);
  const X_Lesion = standardize(data.lesionMaxLongDiameter, mean_lesion, std_lesion);
  const X_CA199 = standardize(data.ca199, mean_ca199, std_ca199,true);
  const X_CEA = standardize(data.cea, mean_cea, std_cea,true);

  // Derived feature: Lesion_Head_neck
  const locHeadNeck = data.lesionLocation.some(l => l === 'Pancreatic Head' || l === 'Pancreatic Neck') ? 1 : 0;

  const calculateClassEtas = (cls: DiagnosisClass) => {
    let eta = 0;
    const contribs: Record<string, number> = {};

    // Coefficients from Pooled_Coefficients.xlsx
    const coefs: Record<DiagnosisClass, any> = {
      [DiagnosisClass.IPMN]: {
        intercept: 0.548563, age: 1.162518, lesion: -0.322304, ca199: 0.469320, cea: 0.041493,
        gender: -0.701825, cystWallUniformYes: 0.017827, tumorMicro: -0.626709, tumorMacro: -0.027972, solidEnhArterial: -0.538432,
        parenAtrophy: -0.136234, mpdComm: 2.769961, mpdDil: -0.063571, septThin: 0.511151, cystWallThin: 0.344634,
        capsule: -0.152047, cystWallEnhDelay: -0.719863, cystWallAbsent: -0.460651, vascular: 0.133219, locHeadNeck: 0.089311,
        solidEnhDelay: -0.144615, cystWallEnhNo: 0.480142
      },
      [DiagnosisClass.MCN]: {
        intercept: 0.050872, age: 0.312816, lesion: 0.143224, ca199: 0.352016, cea: 0.042041,
        gender: 0.323592, cystWallUniformYes: 0.411871, tumorMicro: -0.872944, tumorMacro: 0.219710, solidEnhArterial: -1.054001,
        parenAtrophy: 0.171941, mpdComm: 0.077827, mpdDil: 0.430576, septThin: 0.270473, cystWallThin: 0.487727,
        capsule: -0.529741, cystWallEnhDelay: 0.517120, cystWallAbsent: -0.374931, vascular: 0.277840, locHeadNeck: -0.333482,
        solidEnhDelay: -0.007380, cystWallEnhNo: 0.806111
      },
      [DiagnosisClass.PNET]: {
        intercept: 0.975197, age: -0.024757, lesion: 0.064712, ca199: -0.185809, cea: 0.196933,
        gender: -0.220100, cystWallUniformYes: -0.328725, tumorMicro: 0.171384, tumorMacro: -0.135848, solidEnhArterial: 1.718846,
        parenAtrophy: -0.289013, mpdComm: -1.301965, mpdDil: 0.004490, septThin: -0.956254, cystWallThin: -1.126239,
        capsule: 0.232820, cystWallEnhDelay: 0.063881, cystWallAbsent: 0.299314, vascular: -0.332776, locHeadNeck: 0.165740,
        solidEnhDelay: -0.237933, cystWallEnhNo: -0.581804
      },
      [DiagnosisClass.SCN]: {
        intercept: -0.138979, age: 0.313286, lesion: 0.041711, ca199: -0.166556, cea: -0.039751,
        gender: 0.445730, cystWallUniformYes: 0.396137, tumorMicro: 1.481991, tumorMacro: 0.000351, solidEnhArterial: 0.250292,
        parenAtrophy: 0.527148, mpdComm: -0.715969, mpdDil: -0.204868, septThin: 0.454352, cystWallThin: 1.360335,
        capsule: -1.014245, cystWallEnhDelay: -0.181847, cystWallAbsent: 0.182935, vascular: 0.169211, locHeadNeck: -0.047584,
        solidEnhDelay: -0.256017, cystWallEnhNo: -0.377581
      },
      [DiagnosisClass.SPN]: {
        intercept: -1.435654, age: -1.763863, lesion: 0.072657, ca199: -0.468971, cea: -0.240717,
        gender: 0.152602, cystWallUniformYes: -0.497110, tumorMicro: -0.153722, tumorMacro: -0.056241, solidEnhArterial: -0.376705,
        parenAtrophy: -0.273842, mpdComm: -0.829854, mpdDil: -0.166627, septThin: -0.279722, cystWallThin: -1.066457,
        capsule: 1.463214, cystWallEnhDelay: 0.320709, cystWallAbsent: 0.353333, vascular: -0.247495, locHeadNeck: 0.126014,
        solidEnhDelay: 0.645945, cystWallEnhNo: -0.326868
      }
    };

    const c = coefs[cls];
    eta = c.intercept;
    
    // Continuous variables
    contribs['Age'] = c.age * X_Age;
    contribs['Lesion Size'] = c.lesion * X_Lesion;
    contribs['CA-199'] = c.ca199 * X_CA199;
    contribs['CEA'] = c.cea * X_CEA;
    
    // Categorical variables
    if (is(data.gender, 'Female')) contribs['Female'] = c.gender;
    
    if (is(data.cystWallThicknessUniform, 'Yes')) contribs['Wall Uniformity: Yes'] = c.cystWallUniformYes;
    
    // Tumor lesion type
    if (is(data.tumorLesion, 'Microcystic')) contribs['Tumor: Microcystic'] = c.tumorMicro;
    if (is(data.tumorLesion, 'Macrocystic')) contribs['Tumor: Macrocystic'] = c.tumorMacro;
    
    // Solid component enhancement
    if (is(data.solidEnhancement, 'Early arterial enhancement')) contribs['Solid Enh: Arterial'] = c.solidEnhArterial;
    if (is(data.solidEnhancement, 'Delayed enhancement')) contribs['Solid Enh: Delayed'] = c.solidEnhDelay;
    
    if (is(data.parenchymalAtrophy, 'Yes')) contribs['Atrophy: Yes'] = c.parenAtrophy;
    if (is(data.mainPDCommunication, 'Yes')) contribs['PD Comm: Yes'] = c.mpdComm;
    if (is(data.mpdDilation, 'Yes')) contribs['MPD Dilation: Yes'] = c.mpdDil;
    
    if (locHeadNeck) contribs['Loc: Head/Neck'] = c.locHeadNeck;
    
    if (is(data.intracysticSeptations, 'Thin septations')) contribs['Septations: Thin'] = c.septThin;
    
    // Cyst wall thickness
    if (is(data.cystWallThickness, 'Thin-walled')) contribs['Cyst Wall: Thin'] = c.cystWallThin;
    if (is(data.cystWallThickness, 'Absent cyst wall')) contribs['Cyst Wall: Absent'] = c.cystWallAbsent;
    
    if (is(data.capsule, 'Yes')) contribs['Capsule: Yes'] = c.capsule;
    // Vascular check: preserve previous logic but accept both string 'Yes' and boolean true
    if (is(data.vascularAbutment, 'Yes') ) contribs['Vascular Abutment'] = c.vascular;
    
    // Cyst wall enhancement
    if (is(data.cystWallEnhancement, 'Delayed enhancement')) contribs['Wall Enh: Delayed'] = c.cystWallEnhDelay;
    if (is(data.cystWallEnhancement, 'No enhancement')) contribs['Wall Enh: None'] = c.cystWallEnhNo;

    eta += Object.values(contribs).reduce((a, b) => a + b, 0);

    return { eta, contribs };
  };

  const results = [
    calculateClassEtas(DiagnosisClass.IPMN),
    calculateClassEtas(DiagnosisClass.MCN),
    calculateClassEtas(DiagnosisClass.PNET),
    calculateClassEtas(DiagnosisClass.SCN),
    calculateClassEtas(DiagnosisClass.SPN)
  ];

  const etas = results.map(r => r.eta);
  const probs = softmax(etas);
  const classes = [DiagnosisClass.IPMN, DiagnosisClass.MCN, DiagnosisClass.PNET, DiagnosisClass.SCN, DiagnosisClass.SPN];
  
  let maxIdx = 0;
  for(let i=1; i<probs.length; i++) {
    if(probs[i] > probs[maxIdx]) maxIdx = i;
  }

  const probMap: any = {};
  classes.forEach((c, i) => probMap[c] = probs[i]);

  return {
    class: classes[maxIdx],
    probabilities: probMap,
    contributions: getTopContributions(results[maxIdx].contribs)
  };
};

// --- Model 1: IPMN Risk Prediction (Updated) ---
const predictIPMNRisk = (data: PatientData) => {
  // Params from IPMN.xlsx (Mean, Std)
  const mean_ca199 = 3.585963; const std_ca199 = 1.760769; // Log scale
  const mean_lesion = 37.818182; const std_lesion = 17.732999;
  const mean_mpd = 7.510428; const std_mpd = 5.572931;
  const mean_cea = 1.418248; const std_cea = 0.620236; // Log scale

  const X_CA199 = standardize(data.ca199, mean_ca199, std_ca199, true);
  const X_Lesion = standardize(data.lesionMaxLongDiameter, mean_lesion, std_lesion);
  const X_MPD = standardize(data.mpdMaxDiameter, mean_mpd, std_mpd);
  const X_CEA = standardize(data.cea, mean_cea, std_cea, true);

  // enhancement merge: arterial OR delayed -> enhancement = 1
  const isEnhancement = (data.cystWallEnhancement === 'Delayed enhancement' || data.cystWallEnhancement === 'Early arterial enhancement') ? 1 : 0;

  const calculateRiskEta = (lvl: number) => {
    let eta = 0;
    const contribs: Record<string, number> = {};
    const coefs: any[] = [
      { // Low Risk (0)
        intercept: -0.86661605, 
        ca199: -0.43268060, mpd: -0.40554119, cea: -0.01712162, lesion: -0.56341687,
        vascular: -0.61679678,
        
        // Cyst wall thickness
        wallThickAbsent: 0.00052335, wallThickThick: -0.51935486, wallThickThin: 0.51628826,
        
        // Uniform Septations
        septAbsent: 0.25514972, septNo: -0.52130361, septYes: 0.26361064,
        
        // Cyst wall enhancement (New)
        enhanceYes: 0.19846954, enhanceNo: -0.20153614,
        
        // Uniform Cyst wall (New)
        wallUniNo: -0.60044963, wallUniYes: 0.59738302
      },
      { // Medium Risk (1)
        intercept: -0.13857199, 
        ca199: -0.06857849, mpd: 0.12820499, cea: 0.18246738, lesion: 0.09820202,
        vascular: -0.32146813,

        // Cyst wall thickness
        wallThickAbsent: -0.27660943, wallThickThick: 0.34905141, wallThickThin: -0.06852266,

        // Uniform Septations
        septAbsent: -0.36697818, septNo: 0.30177649, septYes: 0.06912076,

        // Cyst wall enhancement (New)
        enhanceYes: -0.03826284, enhanceNo: 0.31879130,

        // Uniform Cyst wall (New)
        wallUniNo: 0.28426725, wallUniYes: -0.00373850
      },
      { // High Risk (2)
        intercept: 1.00518804, 
        ca199: 0.50125909, mpd: 0.27733620, cea: -0.16534576, lesion: 0.46521485,
        vascular: 0.93826491,

        // Cyst wall thickness
        wallThickAbsent: 0.27608608, wallThickThick: 0.17030345, wallThickThin: -0.44776560,

        // Uniform Septations
        septAbsent: 0.11182847, septNo: 0.21952712, septYes: -0.33273139,

        // Cyst wall enhancement (New)
        enhanceYes: -0.16020670, enhanceNo: -0.11725516,

        // Uniform Cyst wall (New)
        wallUniNo: 0.31618237, wallUniYes: -0.59364453
      }
    ];

    const c = coefs[lvl];
    eta = c.intercept;
    contribs['CA-199'] = c.ca199 * X_CA199;
    contribs['CEA'] = c.cea * X_CEA;
    contribs['Lesion Diameter'] = c.lesion * X_Lesion;
    contribs['MPD Diameter'] = c.mpd * X_MPD;
    
    // Vascular: preserve previous semantics but accept boolean true or string 'Yes'
    if (is(data.vascularAbutment, 'Yes') ) {
        contribs['Vascular Abutment'] = c.vascular;
    }

    // Cyst wall thickness
    // Note: Assuming data.cystWallThickness holds values: 'Absent cyst wall', 'Thick-walled', 'Thin-walled'
    if (is(data.cystWallThickness, 'Absent cyst wall')) contribs['Wall Thickness: Absent'] = c.wallThickAbsent;
    if (is(data.cystWallThickness, 'Thick-walled')) contribs['Wall Thickness: Thick'] = c.wallThickThick;
    if (is(data.cystWallThickness, 'Thin-walled')) contribs['Wall Thickness: Thin'] = c.wallThickThin;

    // Uniform Septations
    if (is(data.septationsUniform, 'Absent septations')) contribs['Septa: Absent'] = c.septAbsent;
    if (is(data.septationsUniform, 'No')) contribs['Septa: Non-uniform'] = c.septNo;
    if (is(data.septationsUniform, 'Yes')) contribs['Septa: Uniform'] = c.septYes;

    // Cyst wall enhancement
    if (isEnhancement) {
      contribs['Wall Enhancement: Yes'] = c.enhanceYes;
    } else if (is(data.cystWallEnhancement, 'No enhancement')) {
      contribs['Wall Enhancement: No'] = c.enhanceNo;
    }

    // Uniform Cyst wall
    if (is(data.cystWallThicknessUniform, 'No')) contribs['Wall Uniformity: No'] = c.wallUniNo;
    if (is(data.cystWallThicknessUniform, 'Yes')) contribs['Wall Uniformity: Yes'] = c.wallUniYes;

    eta += Object.values(contribs).reduce((a, b) => a + b, 0);
    return { eta, contribs };
  };

  const riskRes = [calculateRiskEta(0), calculateRiskEta(1), calculateRiskEta(2)];
  return { 
    etas: riskRes.map(r => r.eta), 
    classes: [RiskLevel.Low, RiskLevel.Medium, RiskLevel.High],
    contribsList: riskRes.map(r => r.contribs)
  };
};

// --- Model 2: MCN Risk Prediction ---
const predictMCNRisk = (data: PatientData) => {
  // Params from Used_Standardization_Parameters MCN.xlsx
  const mean_age = 52.130769; const std_age = 13.707005;
  const mean_mural = 1.422308; const std_mural = 3.993391;
  const mean_solid = 3.681538; const std_solid = 10.656517;
  // CA-199 params added back (log scale)
  const mean_ca199 = 3.585963; const std_ca199 = 1.760769;

  const X_Age = standardize(data.age, mean_age, std_age);
  const X_Mural = standardize(data.muralNoduleShortDiameter, mean_mural, std_mural);
  const X_Solid = standardize(data.solidMaxShortDiameter, mean_solid, std_solid);
  const X_CA199 = standardize(data.ca199, mean_ca199, std_ca199, true);

  const isBodyTail = data.lesionLocation.some(l => l === 'Pancreatic Body' || l === 'Pancreatic Tail') ? 1 : 0;
  // enhancement merge: arterial OR delayed -> enhancement = 1
  const isEnhancement = (data.cystWallEnhancement === 'Delayed enhancement' || data.cystWallEnhancement === 'Early arterial enhancement') ? 1 : 0;

  const calculateRiskEta = (lvl: number) => {
    let eta = 0;
    const contribs: Record<string, number> = {};
    const coefs: any[] = [
      { // Low Risk / Benign
        intercept: 0.926804, diabetes: -0.168973, bodyTail: 0.818612, wallAbsent: -0.037649, 
        wallNo: -0.780473, wallYes: 0.812970, tumorCS: -0.037649, tumorMacro: -0.450389, 
        tumorMicro: -0.216732, tumorUni: 0.699618, mural: 0.005009, 
        enhance: -0.286039, noEnhance: 0.318536, vascular: -0.704740, age: -0.150841, solid: -0.033386
      },
      { // Medium Risk
        intercept: -1.061087, diabetes: -0.330359, bodyTail: -0.150597, wallAbsent: -0.237500, 
        wallNo: 0.343661, wallYes: -0.111686, tumorCS: -0.237500, tumorMacro: 0.341569, 
        tumorMicro: 0.012060, tumorUni: -0.121654, mural: -0.621386, 
        enhance: 0.194008, noEnhance: 0.037968, vascular: 0.268208, age: -0.004467, solid: -0.473688
      },
      { // High Risk
        intercept: 0.134283, diabetes: 0.499332, bodyTail: -0.668015, wallAbsent: 0.275149, 
        wallNo: 0.436812, wallYes: -0.701284, tumorCS: 0.275149, tumorMacro: 0.108820, 
        tumorMicro: 0.204672, tumorUni: -0.577964, mural: 0.616377, 
        enhance: 0.092032, noEnhance: -0.356504, vascular: 0.436532, age: 0.155308, solid: 0.507074
      }
    ];

    const c = coefs[lvl];
    eta = c.intercept;
    contribs['Age'] = c.age * X_Age;
    // Add CA-199 contribution if coefficient exists
    if (typeof c.ca199 !== 'undefined') contribs['CA-199'] = c.ca199 * X_CA199;
    contribs['Mural Nodule Size'] = c.mural * X_Mural;
    contribs['Solid Component Size'] = c.solid * X_Solid;
    
    if (is(data.diabetes, 'Yes')) contribs['Diabetes: Yes'] = c.diabetes;
    if (isBodyTail) contribs['Loc: Body/Tail'] = c.bodyTail;

    if (is(data.cystWallThicknessUniform, 'Absent cyst wall')) contribs['Wall: Absent'] = c.wallAbsent;
    if (is(data.cystWallThicknessUniform, 'No')) contribs['Wall: Non-uniform'] = c.wallNo;
    if (is(data.cystWallThicknessUniform, 'Yes')) contribs['Wall: Uniform'] = c.wallYes;

    if (is(data.tumorLesion, 'Cystic-solid')) contribs['Tumor: Cystic-solid'] = c.tumorCS;
    if (is(data.tumorLesion, 'Macrocystic')) contribs['Tumor: Macrocystic'] = c.tumorMacro;
    if (is(data.tumorLesion, 'Microcystic')) contribs['Tumor: Microcystic'] = c.tumorMicro;
    if (is(data.tumorLesion, 'Unilocular')) contribs['Tumor: Unilocular'] = c.tumorUni;

    // enhancement handling: set enhancement coefficient when either arterial or delayed found
    if (isEnhancement) contribs['Wall Enhance: Yes'] = c.enhance;
    if (is(data.cystWallEnhancement, 'No enhancement')) contribs['Wall Enhance: No'] = c.noEnhance;

    if (is(data.vascularAbutment, 'Yes')) contribs['Vascular Abutment'] = c.vascular;

    eta += Object.values(contribs).reduce((a, b) => a + b, 0);
    return { eta, contribs };
  };

  const riskRes = [calculateRiskEta(0), calculateRiskEta(1), calculateRiskEta(2)];
  return { 
    etas: riskRes.map(r => r.eta), 
    classes: [RiskLevel.Low, RiskLevel.Medium, RiskLevel.High],
    contribsList: riskRes.map(r => r.contribs)
  };
};

// --- Main Prediction Pipeline ---
export const runPrediction = (data: PatientData): PredictionResult => {
  const diagnosisResult = predictDiagnosis(data);
  const result: PredictionResult = {
    diagnosis: diagnosisResult,
    guidelines: evaluateGuidelines(data)
  };

  let riskCalc;
  let modelName = '';

  if (diagnosisResult.class === DiagnosisClass.IPMN) {
    riskCalc = predictIPMNRisk(data);
    modelName = 'IPMN Risk Stratification Model';
  } else if (diagnosisResult.class === DiagnosisClass.MCN || diagnosisResult.class === DiagnosisClass.SCN) {
    riskCalc = predictMCNRisk(data);
    modelName = diagnosisResult.class === DiagnosisClass.MCN 
      ? 'MCN Risk Stratification Model' 
      : 'MCN-based Risk Stratification Model';
  }

  if (riskCalc) {
    const probs = softmax(riskCalc.etas);
    const probMap: any = {};
    let maxIdx = 0;
    riskCalc.classes.forEach((c, i) => {
      probMap[c] = probs[i];
      if (probs[i] > probs[maxIdx]) maxIdx = i;
    });

    result.risk = {
      level: riskCalc.classes[maxIdx],
      probabilities: probMap,
      modelName,
      contributions: getTopContributions(riskCalc.contribsList[maxIdx])
    };
  }

  return result;
};