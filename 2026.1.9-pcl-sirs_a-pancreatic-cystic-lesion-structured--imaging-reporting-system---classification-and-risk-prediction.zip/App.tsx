
import React, { useState, useRef } from 'react';
import { PatientData, PredictionResult } from './types';
import { PredictionForm } from './components/PredictionForm';
import { ResultsView } from './components/ResultsView';
import { runPrediction } from './services/predictionService';
import { exportToExcel, exportBatchToExcel, exportEncodedBatchToExcel } from './services/excelService';
import { exportToPDF, exportBatchToPDF } from './services/pdfService';
import { ChatBot } from './components/ChatBot';
import { parseFile, mapBatchDataWithGemini } from './services/fileImportService';

const initialData: PatientData = {
  patientId: '',
  imagingModality: 'CE-CT',
  examinationDate: new Date().toISOString().split('T')[0],
  age: 60,
  gender: 'Male',
  ca199: 10,
  cea: 2.5,
  diabetes: 'No',
  jaundice: 'No',
  lesionMaxLongDiameter: 25,
  lesionMaxShortDiameter: 20,
  solidMaxLongDiameter: 0,
  solidMaxShortDiameter: 0,
  muralNoduleLongDiameter: 0,
  muralNoduleShortDiameter: 0,
  mpdMaxDiameter: 2,
  cbdMaxDiameter: 4,
  lymphNodeShortDiameter: 0,
  cystWallThickness: 'Thin-walled',
  cystWallThicknessUniform: 'Yes',
  cystWallEnhancement: 'No enhancement',
  solidEnhancement: 'Absent solid component',
  muralNoduleEnhancementDetailed: 'No mural nodule',
  muralNoduleEnhancement: 'No mural nodule',
  intracysticSeptations: 'Absent septations',
  septationsUniform: 'Absent septations',
  septationsEnhancement: 'Absent septations',
  capsule: 'No',
  calcification: 'No calcification',
  mainPDCommunication: 'No',
  mpdDilation: 'No',
  enlargedLymphNodes: 'No',
  distantMetastasis: 'No',
  parenchymalAtrophy: 'No',
  vascularAbutment: 'No',
  tumorLesion: 'Unilocular',
  lesionLocation: []
};

const demoIPMNHighRisk: PatientData = { ...initialData, patientId: 'DEMO-IPMN-001', imagingModality: 'CE-CT', examinationDate: '2024-05-15', age: 72, gender: 'Male', ca199: 200, cea: 5.5, jaundice: 'Yes', lesionMaxLongDiameter: 52, lesionMaxShortDiameter: 45, mpdMaxDiameter: 12, mpdDilation: 'Yes', muralNoduleLongDiameter: 10, muralNoduleShortDiameter: 8, muralNoduleEnhancementDetailed: 'Early arterial enhancement', mainPDCommunication: 'Yes', cystWallThickness: 'Thick-walled', lesionLocation: ['Pancreatic Head'] };
const demoMCN: PatientData = { ...initialData, patientId: 'DEMO-MCN-002', imagingModality: 'CE-MRI', examinationDate: '2024-06-20', calcification: 'MRI Scan', age: 45, gender: 'Female', cea: 400, lesionMaxLongDiameter: 42, lesionMaxShortDiameter: 38, lesionLocation: ['Pancreatic Body', 'Pancreatic Tail'], capsule: 'Yes', intracysticSeptations: 'Thin septations', septationsUniform: 'Yes', tumorLesion: 'Macrocystic' };
const demoSCN: PatientData = { ...initialData, patientId: 'DEMO-SCN-003', imagingModality: 'CE-CT', examinationDate: '2024-07-10', age: 65, gender: 'Female', lesionMaxLongDiameter: 35, lesionMaxShortDiameter: 32, tumorLesion: 'Microcystic', calcification: 'Predominantly central calcification', lesionLocation: ['Pancreatic Head'], intracysticSeptations: 'Thin septations' };
const demoPNET: PatientData = { ...initialData, patientId: 'DEMO-PNET-004', imagingModality: 'CE-CT', examinationDate: '2024-08-05', age: 20, gender: 'Male', ca199: 15, cea: 100, lesionMaxLongDiameter: 40, lesionMaxShortDiameter: 35, tumorLesion: 'Cystic-solid', solidMaxLongDiameter: 25, solidMaxShortDiameter: 20, solidEnhancement: 'Early arterial enhancement', lesionLocation: ['Pancreatic Head'], intracysticSeptations: 'Absent septations', mainPDCommunication: 'No', mpdDilation: 'No', cystWallThickness: 'Absent cyst wall' };
const demoSPN: PatientData = { ...initialData, patientId: 'DEMO-SPN-005', imagingModality: 'CE-MRI', examinationDate: '2024-09-12', age: 18, gender: 'Female', ca199: 5, cea: 1.0, lesionMaxLongDiameter: 90, lesionMaxShortDiameter: 85, tumorLesion: 'Cystic-solid', capsule: 'Yes', solidMaxLongDiameter: 55, solidMaxShortDiameter: 48, solidEnhancement: 'Delayed enhancement', lesionLocation: ['Pancreatic Tail'], intracysticSeptations: 'Absent septations', mainPDCommunication: 'No', cystWallThickness: 'Absent cyst wall' };

const App: React.FC = () => {
  const [data, setData] = useState<PatientData>(initialData);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [batchResults, setBatchResults] = useState<{data: PatientData, result: PredictionResult}[] | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importProgress, setImportProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFieldChange = (field: keyof PatientData, value: any) => {
    setData(prev => {
        const newData = { ...prev, [field]: value };
        if (field === 'imagingModality' && value === 'CE-MRI') newData.calcification = 'MRI Scan';
        if (field === 'mpdMaxDiameter') newData.mpdDilation = value >= 3 ? 'Yes' : 'No';
        if (field === 'tumorLesion') {
          if (value === 'Cystic-solid') {
            newData.cystWallThickness = 'Absent cyst wall';
            newData.cystWallThicknessUniform = 'Absent cyst wall';
            newData.cystWallEnhancement = 'Absent cyst wall';
            if (newData.solidEnhancement === 'Absent solid component') newData.solidEnhancement = 'No enhancement';
          } else if (newData.cystWallThickness === 'Absent cyst wall') {
            newData.cystWallThickness = 'Thin-walled';
            newData.cystWallThicknessUniform = 'Yes';
            newData.cystWallEnhancement = 'No enhancement';
          }
        }
        if (field === 'cystWallThickness' && value === 'Absent cyst wall') {
            newData.cystWallThicknessUniform = 'Absent cyst wall';
            newData.cystWallEnhancement = 'Absent cyst wall';
        }
        if (field === 'intracysticSeptations' && value === 'Absent septations') {
            newData.septationsUniform = 'Absent septations';
            newData.septationsEnhancement = 'Absent septations';
        }
        if (field === 'solidEnhancement' && value === 'Absent solid component') {
            newData.solidMaxLongDiameter = 0;
            newData.solidMaxShortDiameter = 0;
        }
        if (field === 'muralNoduleEnhancementDetailed' && value === 'No mural nodule') {
            newData.muralNoduleLongDiameter = 0;
            newData.muralNoduleShortDiameter = 0;
        }
        return newData;
    });
  };

  const handleSmartImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsImporting(true);
    setImportProgress(0);
    try {
      const rawRows = await parseFile(file);
      const analyzedBatch: {data: PatientData, result: PredictionResult}[] = [];
      const BATCH_SIZE = 5; 
      for (let i = 0; i < rawRows.length; i += BATCH_SIZE) {
        const chunk = rawRows.slice(i, i + BATCH_SIZE);
        const mappedChunks = await mapBatchDataWithGemini(chunk);
        mappedChunks.forEach(mappedData => {
          const fullPatientData = { ...initialData, ...mappedData } as PatientData;
          if (fullPatientData.imagingModality === 'CE-MRI') fullPatientData.calcification = 'MRI Scan';
          fullPatientData.mpdDilation = fullPatientData.mpdMaxDiameter >= 3 ? 'Yes' : 'No';
          const predResult = runPrediction(fullPatientData);
          analyzedBatch.push({ data: fullPatientData, result: predResult });
        });
        setImportProgress(Math.min(100, Math.round(((i + BATCH_SIZE) / rawRows.length) * 100)));
      }
      setBatchResults(analyzedBatch);
      setResult(null); 
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error(err);
      alert("Failed to process clinical data file.");
    } finally {
      setIsImporting(false);
      setImportProgress(0);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSubmit = () => {
    if (!data.patientId.trim()) { alert("Please provide a Patient ID."); return; }
    if (data.tumorLesion === 'Cystic-solid' && (data.solidMaxLongDiameter <= 0 || data.solidMaxShortDiameter <= 0)) { alert("For Cystic-solid lesions, please provide the Size of Solid (Long and Short diameters)."); return; }
    setResult(runPrediction(data));
    setBatchResults(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleViewCase = (item: {data: PatientData, result: PredictionResult}) => {
    setData(item.data);
    setResult(item.result);
    setBatchResults(null); 
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const generateNewId = () => setData({ ...initialData, patientId: `PAT-${new Date().getTime().toString().slice(-6)}` });

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      <header className="bg-gradient-to-r from-medical-800 to-medical-900 text-white shadow-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-center md:text-left"><h1 className="text-xl font-bold tracking-tight">Pancreatic Cystic Lesion Structured Imaging Reporting System</h1><p className="text-medical-100 text-xs opacity-90 tracking-wide font-bold tracking-[0.1em] uppercase"> Pathological Classification & Risk Stratification</p></div>
          <div className="flex items-center gap-3"><span className="text-xs text-medical-200 bg-black/20 px-3 py-1 rounded-full border border-white/10 font-medium">Clinical Research Edition</span></div>
        </div>
      </header>
      <main className="py-8 px-4">
        {!result && !batchResults ? (
          <>
            <div className="max-w-5xl mx-auto text-center mb-10"><h2 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight uppercase">PCL-SIRS</h2><p className="text-gray-500 max-w-4xl mx-auto mb-8 text-lg leading-relaxed">A five-class pathological predictor (IPMN, MCN, SCN, SPN, PNET) coupled with separate three-tier malignancy-risk models for IPMN and MCN, built from a large, multicentre cohort of incidentally detected cysts. The tool is designed for non-invasive, point-of-care use to optimise surveillance intensity and streamline surgical referral.</p>
              <div className="flex flex-col items-center gap-8"><div className="flex flex-wrap justify-center gap-6 w-full max-w-3xl"><button onClick={generateNewId} className="flex-1 min-w-[280px] h-[72px] px-8 py-4 text-base font-bold text-white bg-medical-600 rounded-xl hover:bg-medical-700 shadow-xl transform hover:-translate-y-1 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3 border-2 border-medical-500 group"><svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 group-hover:rotate-90 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>Manual New Patient Entry</button><input type="file" ref={fileInputRef} onChange={handleSmartImport} className="hidden" accept=".xlsx, .csv" /><button onClick={() => fileInputRef.current?.click()} disabled={isImporting} className="flex-1 min-w-[280px] h-[72px] px-8 py-4 text-base font-bold text-medical-700 bg-white rounded-xl hover:bg-medical-50 shadow-xl transform hover:-translate-y-1 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-3 border-2 border-medical-200 group overflow-hidden relative"><span className="absolute inset-0 bg-medical-500/5 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></span><div className="relative flex items-center gap-3">{isImporting ? <div className="animate-spin h-6 w-6 border-2 border-medical-500 border-t-transparent rounded-full"></div> : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>}<span>{isImporting ? `AI Processing (${importProgress}%)...` : 'Turbo AI Batch Import'}</span></div></button></div>
                <div className="flex flex-wrap gap-4 justify-center opacity-70"><button onClick={() => setData(demoIPMNHighRisk)} className="text-xs font-bold text-medical-700 bg-medical-50 px-3 py-1.5 rounded-lg hover:bg-medical-100 transition-colors uppercase border border-medical-200">Load IPMN Demo</button><button onClick={() => setData(demoMCN)} className="text-xs font-bold text-orange-700 bg-orange-50 px-3 py-1.5 rounded-lg hover:bg-orange-100 transition-colors uppercase border border-orange-200">Load MCN Demo</button><button onClick={() => setData(demoSCN)} className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg hover:bg-emerald-100 transition-colors uppercase border border-emerald-200">Load SCN Demo</button><button onClick={() => setData(demoPNET)} className="text-xs font-bold text-red-700 bg-red-50 px-3 py-1.5 rounded-lg hover:bg-red-100 transition-colors uppercase border border-red-200">Load PNET Demo</button><button onClick={() => setData(demoSPN)} className="text-xs font-bold text-violet-700 bg-violet-50 px-3 py-1.5 rounded-lg hover:bg-violet-100 transition-colors uppercase border border-violet-200">Load SPN Demo</button></div>
              </div>
            </div>
            <div className="mt-12"><PredictionForm data={data} onChange={handleFieldChange} onSubmit={handleSubmit} /></div>
          </>
        ) : (
          <ResultsView 
            data={data}
            result={result!} 
            batchResults={batchResults}
            onReset={() => { setResult(null); setBatchResults(null); }} 
            onExportExcel={() => exportToExcel(data, result!)}
            onExportEncodedExcel={() => exportEncodedBatchToExcel([{data, result: result!}])}
            onExportBatchExcel={() => batchResults && exportBatchToExcel(batchResults)}
            onExportBatchEncodedExcel={() => batchResults && exportEncodedBatchToExcel(batchResults)}
            onExportBatchPDF={() => batchResults && exportBatchToPDF(batchResults)}
            onExportPDF={() => exportToPDF(data, result!)}
            onViewCase={handleViewCase}
          />
        )}
      </main>
      <footer className="bg-white border-t mt-16 py-12 text-center text-gray-500 text-sm"><div className="max-w-4xl mx-auto px-4"><p className="font-semibold text-gray-700 mb-2 tracking-tight">Pancreatic Cystic Lesion Standalone Platform</p><p className="text-xs text-gray-400 leading-relaxed max-w-xl mx-auto italic">Clinical research decision support tool. Core prediction logic remains fast and reliable.</p></div></footer>
      <ChatBot />
    </div>
  );
};

export default App;