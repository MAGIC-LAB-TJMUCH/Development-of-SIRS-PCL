
import React, { useState, useEffect, useRef } from 'react';
import { PatientData } from '../types';

interface Props {
  data: PatientData;
  onChange: (field: keyof PatientData, value: any) => void;
  onSubmit: () => void;
}

// Visual Reference Data Store
const FEATURE_REFS: Record<string, { title: string; definition: string; imgUrl: string }> = {
  'cystWallThickness': {
    title: 'Cyst Wall Thickness',
    definition: 'In this study, a septum is defined as a discernible, continuous linear structure traversing the cystic lumen and tethering the opposing cyst walls. On the post-contrast axial plane that most clearly delineates the septal architecture, the maximum thickness is measured perpendicularly at the straightest segment. Septa are thereby categorized as thick (maximum thickness ≥ 2 mm) or thin (maximum thickness < 2 mm). When multiple septa are present, the greatest thickness recorded among all septa serves as the definitive value for classification.',
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Cyst%20wall.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'cystWallThicknessUniform': {
    title: 'Cyst Wall Uniform',
    definition: `1. Uniform: The septal thickness changes gradually, is smooth and continuous, and shows no focal abrupt alterations.
2. Non-uniform: The septal thickness changes progressively, with the entire septum or focal areas exhibiting a “beaded” appearance.
In multiple septated lesions, if any single septum is judged non-uniform, the septation of the entire lesion is recorded as non-uniform.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Cyst%20wall.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'cystWallEnhancement': {
    title: 'Wall Enhancement',
    definition: `1.No enhancement: No perceptible change in CT attenuation or MRI signal intensity between the unenhanced and any post-contrast phase.
2.Arterial-phase enhancement: A definite and marked increase in CT attenuation or MRI signal intensity is seen in the arterial phase, exceeding that of the surrounding normal pancreatic parenchyma, followed by persistent wash-out, plateau, or further enhancement on portal-venous and delayed phases.
3.Delayed enhancement: No or only minimal enhancement in the arterial phase, with a progressive, gradual increase in enhancement on portal-venous and delayed phases, typically peaking on the delayed phase.
On contrast-enhanced CT or MRI, the enhancement pattern of the cyst wall, mural nodule, septa, and solid component was assessed separately.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Enhancement.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'intracysticSeptations': {
    title: 'Intracystic Septations',
    definition: 'In this study, a septum is defined as a discernible, continuous linear structure traversing the cystic lumen and tethering the opposing cyst walls. On the post-contrast axial plane that most clearly delineates the septal architecture, the maximum thickness is measured perpendicularly at the straightest segment. Septa are thereby categorized as thick (maximum thickness ≥ 2 mm) or thin (maximum thickness < 2 mm). When multiple septa are present, the greatest thickness recorded among all septa serves as the definitive value for classification.',
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Septation.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'septationsUniform': {
    title: 'Septations Uniform',
    definition: `Uniform: The septal thickness changes gradually, is smooth and continuous, and shows no focal abrupt alterations.
Non-uniform: The septal thickness changes progressively, with the entire septum or focal areas exhibiting a “beaded” appearance.

In multiple septated lesions, if any single septum is judged non-uniform, the septation of the entire lesion is recorded as non-uniform.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Septation.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'septationsEnhancement': {
    title: 'Septations Enhancement',
    definition: `1.No enhancement: No perceptible change in CT attenuation or MRI signal intensity between the unenhanced and any post-contrast phase.
2.Arterial-phase enhancement: A definite and marked increase in CT attenuation or MRI signal intensity is seen in the arterial phase, exceeding that of the surrounding normal pancreatic parenchyma, followed by persistent wash-out, plateau, or further enhancement on portal-venous and delayed phases.
3.Delayed enhancement: No or only minimal enhancement in the arterial phase, with a progressive, gradual increase in enhancement on portal-venous and delayed phases, typically peaking on the delayed phase.
On contrast-enhanced CT or MRI, the enhancement pattern of the cyst wall, mural nodule, septa, and solid component was assessed separately.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Enhancement.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'solidEnhancement': {
    title: 'Solid Component Enhancement',
    definition: `1.No enhancement: No perceptible change in CT attenuation or MRI signal intensity between the unenhanced and any post-contrast phase.
2.Arterial-phase enhancement: A definite and marked increase in CT attenuation or MRI signal intensity is seen in the arterial phase, exceeding that of the surrounding normal pancreatic parenchyma, followed by persistent wash-out, plateau, or further enhancement on portal-venous and delayed phases.
3.Delayed enhancement: No or only minimal enhancement in the arterial phase, with a progressive, gradual increase in enhancement on portal-venous and delayed phases, typically peaking on the delayed phase.
On contrast-enhanced CT or MRI, the enhancement pattern of the cyst wall, mural nodule, septa, and solid component was assessed separately.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Enhancement.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'muralNoduleEnhancementDetailed': {
    title: 'Mural Nodule Enhancement',
    definition: `1.No enhancement: No perceptible change in CT attenuation or MRI signal intensity between the unenhanced and any post-contrast phase.
2.Arterial-phase enhancement: A definite and marked increase in CT attenuation or MRI signal intensity is seen in the arterial phase, exceeding that of the surrounding normal pancreatic parenchyma, followed by persistent wash-out, plateau, or further enhancement on portal-venous and delayed phases.
3.Delayed enhancement: No or only minimal enhancement in the arterial phase, with a progressive, gradual increase in enhancement on portal-venous and delayed phases, typically peaking on the delayed phase.
On contrast-enhanced CT or MRI, the enhancement pattern of the cyst wall, mural nodule, septa, and solid component was assessed separately.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Enhancement.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'capsule': {
    title: 'Capsule',
    definition: 'A distinct peripheral rim separating the cyst from normal parenchyma. Commonly seen in MCN and SPN lesions.',
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/8.Capsule.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'calcification': {
    title: 'Calcification',
    definition: `In this study, calcification status was assessed exclusively on CT images. Calcification was defined as an intralesional hyperdense focus approximating cortical bone density (CT value > 100 HU). Based on location, calcifications were classified as follows:
1.No calcification: No definite calcification identified.
2.Central calcification: Calcification entirely within the lesion.
3.Peripheral calcification: Calcification located at the lesion margin or within the cyst wall.
4.Both central and peripheral calcification: Coexistence of internal and marginal calcification.
5.Cases examined solely with MRI were not evaluated for calcification.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Calcification.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'tumorLesion': {
    title: 'Tumor Lesion Type',
    definition: `1. Unilocular: a single fluid-filled cavity without any identifiable internal septa.
2. Macrocystic: a lesion composed of multiple cysts, the largest of which measures ≥ 2cm in diameter.
3. Microcystic: a lesion composed of multiple cysts, the largest of which measures < 2cm in diameter.
4. Cystic-solid: a lesion that contains both a definite cystic portion and an independent solid component occupying > 50 % of the total lesion volume.

In this study, for lesions containing solid elements, the approximate volumetric proportion of solid tissue was assessed on the most complete axial, coronal, and sagittal post-contrast images. If the solid component was judged to exceed 50 % of the entire lesion on at least two imaging planes, the lesion was classified as “cystic-solid”; otherwise, its underlying cystic morphology (unilocular, macrocystic, or microcystic) was retained and annotated as “with mural nodule.” A mural nodule typically appears as a localized, papillary, or nodular solid projection attached to the cyst wall or a septation.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Morphology.png?auto=format&fit=clip&q=80&w=1920&h=1080'
  },
  'mainPDCommunication': {
    title: 'PD Communication',
    definition: `1.Communication: A definite continuity between the lesion and the pancreatic duct is visible, or the lesion shows the classic “grape-cluster” appearance of dilated side branches.
2.No communication: No such continuity is identified; pancreatic parenchyma separates the lesion from the duct.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/5.MPD.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
  'mpdDilation': {
    title: 'MPD Dilation',
    definition: 'Pancreatic duct dilation is defined as a focal or diffuse pathologic widening of the main pancreatic duct (MPD). On axial images, the widest intraparenchymal MPD diameter is measured; < 3 mm is recorded as “no dilation,” ≥ 3 mm as “dilation.” This assessment refers only to MPD caliber; side-branch morphology and communication with the lesion are not considered.',
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/5.MPD.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
 
  'vascularAbutment': {
    title: 'Vascular Abutment',
    definition: `Assessment of the relationship between the lesion and adjacent critical vessels (celiac trunk, superior mesenteric artery/vein, portal venous system, etc.).
1.No invasion: A clear fat plane or normal pancreatic parenchyma is interposed between the lesion and the vessel, or the lesion merely abuts the vessel without alteration of its contour, caliber, or wall smoothness.
2.Invasion: the lesion encircles >50 % of the vessel circumference or causes definite morphologic changes such as stenosis, irregularity of the vessel wall, or occlusion.`,
    imgUrl: 'https://694ba178f54bb99ca8ce9b7f.imgix.net/Vascular%20Involvement.png?auto=format&fit=crop&q=80&w=1920&h=1080'
  },
};

// Tooltip component optimized for visibility and viewport safety
const FeatureIllustration = ({ featureKey, onClose }: { featureKey: string, onClose: () => void }) => {
  const ref = FEATURE_REFS[featureKey];
  if (!ref) return null;

  return (
    <div 
      onMouseLeave={onClose}
      className="absolute z-[100] bottom-[calc(100%+12px)] left-1/2 -translate-x-1/2 mb-4 w-[544px] 
                    transition-all duration-300 ease-out 
                    transform translate-y-0 scale-100 origin-bottom pointer-events-auto"
    >
      <div className="backdrop-blur-3xl bg-gray-900/95 border border-white/20 rounded-3xl shadow-[0_30px_60px_-12px_rgba(0,0,0,0.6)] overflow-hidden">
        {/* Illustration Area */}
        <div className="relative aspect-video w-full bg-white">
          <img src={ref.imgUrl} alt={ref.title} className="w-full h-full object-cover" />
        </div>
        
        {/* Content Area */}
        <div className="p-6">
          <h4 className="text-lg font-black text-white mb-2 flex items-center gap-3">
            <span className="w-1.5 h-5 bg-medical-500 rounded-full"></span>
            {ref.title}
          </h4>
          <p className="text-sm text-gray-300 leading-relaxed font-medium whitespace-pre-line">
            {ref.definition}
          </p>
        </div>
      </div>
      {/* Arrow */}
      <div className="absolute top-full left-1/2 -translate-x-1/2 border-[10px] border-transparent border-t-gray-900/95"></div>
    </div>
  );
};

// Reusable Label component with click and click-outside logic
const LabelWithRef = ({ label, featureKey }: { label: string; featureKey?: string }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    } else {
      document.removeEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  return (
    <div ref={containerRef} className="flex items-center gap-2.5 mb-2 relative">
      <label className="text-[11px] font-black text-gray-500 tracking-widest leading-none">{label}</label>
      {featureKey && FEATURE_REFS[featureKey] && (
        <div className="flex items-center justify-center relative">
          <button 
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className={`w-5 h-5 rounded-full border shadow-sm flex items-center justify-center transition-all duration-200 ${
              isOpen ? 'bg-medical-600 text-white border-medical-600' : 'bg-white text-medical-600 border-gray-200 hover:bg-medical-50'
            }`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M12 16v-4"></path>
              <path d="M12 8h.01"></path>
            </svg>
          </button>
          {isOpen && (
            <FeatureIllustration 
              featureKey={featureKey} 
              onClose={() => setIsOpen(false)} 
            />
          )}
        </div>
      )}
    </div>
  );
};

const InputGroup = ({ title, children }: { title: string, children?: React.ReactNode }) => (
  <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 mb-6 transition-all hover:shadow-md">
    <h3 className="text-lg font-semibold text-gray-800 mb-4 border-b pb-2 flex items-center">
      <span className="bg-medical-50 text-medical-600 w-1 h-6 rounded mr-2"></span>
      {title}
    </h3>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {children}
    </div>
  </div>
);

const formatOptionLabel = (opt: string) => {
  if (opt === 'nan' || opt === 'NA') return 'Unknown / Not Available';
  return opt;
};

const TextInput = ({ label, value, onChange, placeholder }: { label: string, value: string, onChange: (val: string) => void, placeholder?: string }) => (
  <div className="flex flex-col group">
    <LabelWithRef label={label} />
    <input 
      type="text"
      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors h-[42px]"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
    />
  </div>
);

const DateInput = ({ label, value, onChange }: { label: string, value: string, onChange: (val: string) => void }) => (
  <div className="flex flex-col group">
    <LabelWithRef label={label} />
    <input 
      type="date"
      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors h-[42px] bg-gray-50"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    />
  </div>
);

const Select = ({ label, value, options, onChange, featureKey, disabled }: { label: string, value: string, options: string[], onChange: (val: string) => void, featureKey?: string, disabled?: boolean }) => (
  <div className={`flex flex-col relative ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}>
    <LabelWithRef label={label} featureKey={featureKey} />
    <select 
      disabled={disabled}
      className={`block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors h-[42px] ${disabled ? 'bg-gray-100 cursor-not-allowed' : 'bg-gray-50 hover:bg-white cursor-pointer'}`}
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      {options.map(opt => (
        <option key={opt} value={opt}>
          {formatOptionLabel(opt)}
        </option>
      ))}
    </select>
  </div>
);

const NumberInput = ({ label, value, onChange, min = 0 }: { label: string, value: number, onChange: (val: number) => void, min?: number }) => (
  <div className="flex flex-col group">
    <LabelWithRef label={label} />
    <input 
      type="number"
      step="0.1"
      min={min}
      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 sm:text-sm p-2.5 border transition-colors h-[42px]"
      value={value}
      onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
    />
  </div>
);

const SizeInputPair = ({ label, longValue, shortValue, onLongChange, onShortChange, disabled }: { 
  label: string, 
  longValue: number, 
  shortValue: number, 
  onLongChange: (val: number) => void, 
  onShortChange: (val: number) => void,
  disabled?: boolean
}) => (
  <div className={`flex flex-col group ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}>
    <LabelWithRef label={label} />
    <div className="flex gap-2">
      <div className="flex-1 relative">
        <input 
          type="number" 
          step="0.1"
          disabled={disabled}
          className={`block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 text-xs p-2.5 pl-8 border h-[42px] ${disabled ? 'bg-gray-100' : ''}`}
          value={longValue}
          onChange={(e) => onLongChange(parseFloat(e.target.value) || 0)}
        />
        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[9px] font-black text-gray-400">LD</span>
      </div>
      <div className="flex-1 relative">
        <input 
          type="number" 
          step="0.1"
          disabled={disabled}
          className={`block w-full rounded-md border-gray-300 shadow-sm focus:border-medical-500 focus:ring-medical-500 text-xs p-2.5 pl-8 border h-[42px] ${disabled ? 'bg-gray-100' : ''}`}
          value={shortValue}
          onChange={(e) => onShortChange(parseFloat(e.target.value) || 0)}
        />
        <span className="absolute left-2 top-1/2 -translate-y-1/2 text-[9px] font-black text-gray-400">SD</span>
      </div>
    </div>
  </div>
);

const MultiSelect = ({ label, selected, options, onChange, featureKey }: { label: string, selected: string[], options: string[], onChange: (val: string[]) => void, featureKey?: string }) => {
  const toggle = (opt: string) => {
    if (selected.includes(opt)) {
      onChange(selected.filter(i => i !== opt));
    } else {
      onChange([...selected, opt]);
    }
  };

  return (
    <div className="flex flex-col relative">
      <div className="flex justify-between items-center mb-1">
        <LabelWithRef label={label} featureKey={featureKey} />
        <span className="text-[9px] font-black text-medical-600 bg-medical-50 px-1.5 py-0.5 rounded tracking-tighter">Multi-Select</span>
      </div>
      <div className="flex items-stretch gap-1 p-1 bg-gray-50 rounded-md border border-gray-200 h-[42px]">
        {options.map((opt) => {
          const isSelected = selected.includes(opt);
          const shortName = opt.replace('Pancreatic ', '');
          return (
            <button
              key={opt}
              type="button"
              onClick={() => toggle(opt)}
              title={opt}
              className={`flex-1 flex items-center justify-center gap-1 px-1 rounded text-[10px] font-bold transition-all duration-200 border ${
                isSelected 
                ? 'bg-medical-600 text-white border-medical-700 shadow-sm' 
                : 'bg-white text-gray-500 border-gray-100 hover:border-medical-300 hover:text-medical-600'
              }`}
            >
              <div className={`w-2.5 h-2.5 rounded-full border flex items-center justify-center shrink-0 ${
                isSelected ? 'bg-white border-white' : 'bg-gray-100 border-gray-300'
              }`}>
                {isSelected && (
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-2 w-2 text-medical-600" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                )}
              </div>
              <span className="truncate">{shortName}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export const PredictionForm: React.FC<Props> = ({ data, onChange, onSubmit }) => {
  const isCysticSolid = data.tumorLesion === 'Cystic-solid';

  return (
    <div className="max-w-7xl mx-auto pb-32">
      <InputGroup title="Examination Item">
        <TextInput 
          label="Patient ID / Case Number" 
          value={data.patientId} 
          onChange={(v) => onChange('patientId', v)} 
          placeholder="e.g. PAT-2024-001" 
        />
        <Select 
          label="Imaging Modality" 
          value={data.imagingModality} 
          options={['CE-CT', 'CE-MRI']} 
          onChange={(v) => onChange('imagingModality', v)} 
        />
        <DateInput
          label="Examination Date"
          value={data.examinationDate}
          onChange={(v) => onChange('examinationDate', v)}
        />
      </InputGroup>

      <InputGroup title="Patient Administrative & Clinical">
        <NumberInput label="Age (years)" value={data.age} onChange={(v) => onChange('age', v)} />
        <Select label="Gender" value={data.gender} options={['Male', 'Female']} onChange={(v) => onChange('gender', v)} />
        <NumberInput label="CA-199 (U/mL)" value={data.ca199} onChange={(v) => onChange('ca199', v)} />
        <NumberInput label="CEA (ng/mL)" value={data.cea} onChange={(v) => onChange('cea', v)} />
        <Select label="Jaundice" value={data.jaundice} options={['No', 'Yes', 'nan']} onChange={(v) => onChange('jaundice', v)} />
        <Select label="Diabetes" value={data.diabetes} options={['No', 'Yes', 'NA']} onChange={(v) => onChange('diabetes', v)} />
      </InputGroup>

      <InputGroup title="Cyst Imaging Characteristics">
        <MultiSelect 
          label="Lesion Location" 
          selected={data.lesionLocation} 
          options={['Pancreatic Head', 'Pancreatic Neck', 'Pancreatic Body', 'Pancreatic Tail']} 
          onChange={(v) => onChange('lesionLocation', v)} 
        />
        <Select label="Cyst Lesion Type" value={data.tumorLesion} options={['Cystic-solid', 'Macrocystic', 'Microcystic', 'Unilocular']} onChange={(v) => onChange('tumorLesion', v)} featureKey="tumorLesion" />
        <Select label="Solid Component Enhancement" value={data.solidEnhancement} options={['Absent solid component', 'No enhancement', 'Delayed enhancement', 'Early arterial enhancement']} onChange={(v) => onChange('solidEnhancement', v)} featureKey="solidEnhancement" />
        <Select 
          label="Cyst Wall Thickness" 
          value={data.cystWallThickness} 
          options={['Absent cyst wall', 'Thick-walled', 'Thin-walled']} 
          onChange={(v) => onChange('cystWallThickness', v)} 
          featureKey="cystWallThickness" 
          disabled={isCysticSolid}
        />
        <Select 
          label="Cyst Wall Uniform" 
          value={data.cystWallThicknessUniform} 
          options={['Absent cyst wall', 'Yes', 'No']} 
          onChange={(v) => onChange('cystWallThicknessUniform', v)} 
          featureKey="cystWallThicknessUniform" 
          disabled={isCysticSolid}
        />
        <Select 
          label="Cyst Wall Enhancement" 
          value={data.cystWallEnhancement} 
          options={['Absent cyst wall', 'No enhancement', 'Delayed enhancement', 'Early arterial enhancement']} 
          onChange={(v) => onChange('cystWallEnhancement', v)} 
          featureKey="cystWallEnhancement" 
          disabled={isCysticSolid}
        />
        <Select label="Intracystic Septations" value={data.intracysticSeptations} options={['Absent septations', 'Thick septations', 'Thin septations']} onChange={(v) => onChange('intracysticSeptations', v)} featureKey="intracysticSeptations" />
        <Select label="Septations Uniform" value={data.septationsUniform} options={['Absent septations', 'Yes', 'No']} onChange={(v) => onChange('septationsUniform', v)} featureKey="septationsUniform" />
        <Select label="Septations Enhancement" value={data.septationsEnhancement} options={['Absent septations', 'No enhancement', 'Delayed enhancement', 'Early arterial enhancement']} onChange={(v) => onChange('septationsEnhancement', v)} featureKey="septationsEnhancement" />
        <Select label="PD Communication" value={data.mainPDCommunication} options={['No', 'Yes']} onChange={(v) => onChange('mainPDCommunication', v)} featureKey="mainPDCommunication" />
        <Select label="MPD Dilation" value={data.mpdDilation} options={['No', 'Yes']} onChange={(v) => onChange('mpdDilation', v)} featureKey="mpdDilation" />
        <Select label="Mural Nodule Enhancement" value={data.muralNoduleEnhancementDetailed} options={['No mural nodule', 'No enhancement', 'Delayed enhancement', 'Early arterial enhancement']} onChange={(v) => onChange('muralNoduleEnhancementDetailed', v)} featureKey="muralNoduleEnhancementDetailed" />
      </InputGroup>

      <InputGroup title="Lesion Dimensions (mm)">
        <SizeInputPair 
          label="Size of Lesion (Long/Short)"
          longValue={data.lesionMaxLongDiameter}
          shortValue={data.lesionMaxShortDiameter}
          onLongChange={(v) => onChange('lesionMaxLongDiameter', v)}
          onShortChange={(v) => onChange('lesionMaxShortDiameter', v)}
        />
        <SizeInputPair 
          label="Size of Solid (Long/Short)"
          longValue={data.solidMaxLongDiameter}
          shortValue={data.solidMaxShortDiameter}
          onLongChange={(v) => onChange('solidMaxLongDiameter', v)}
          onShortChange={(v) => onChange('solidMaxShortDiameter', v)}
        />
        <SizeInputPair 
          label="Size of Mural Nodule (Long/Short)"
          longValue={data.muralNoduleLongDiameter}
          shortValue={data.muralNoduleShortDiameter}
          onLongChange={(v) => onChange('muralNoduleLongDiameter', v)}
          onShortChange={(v) => onChange('muralNoduleShortDiameter', v)}
        />
        <NumberInput label="MPD Diameter" value={data.mpdMaxDiameter} onChange={(v) => onChange('mpdMaxDiameter', v)} />
        <NumberInput label="Common Bile Duct (CBD)" value={data.cbdMaxDiameter} onChange={(v) => onChange('cbdMaxDiameter', v)} />
        <NumberInput label="Largest Lymph Node Short Diameter." value={data.lymphNodeShortDiameter} onChange={(v) => onChange('lymphNodeShortDiameter', v)} />
      </InputGroup>

      <InputGroup title="Anatomy & Relations">
        <Select label="Capsule" value={data.capsule} options={['No', 'Yes']} onChange={(v) => onChange('capsule', v)} featureKey="capsule" />
        <Select 
          label="Calcification" 
          value={data.calcification} 
          options={['No calcification', 'Predominantly peripheral calcification', 'Predominantly central calcification', 'Calcification foci visible in both central and peripheral areas', 'MRI Scan']} 
          onChange={(v) => onChange('calcification', v)} 
          featureKey="calcification" 
          disabled={data.imagingModality === 'CE-MRI'}
        />
        <Select label="Parenchymal Atrophy" value={data.parenchymalAtrophy} options={['No', 'Yes']} onChange={(v) => onChange('parenchymalAtrophy', v)} featureKey="parenchymalAtrophy" />
        <Select label="Vascular Abutment" value={data.vascularAbutment} options={['No', 'Yes']} onChange={(v) => onChange('vascularAbutment', v)} featureKey="vascularAbutment" />
        <Select label="Enlarged Lymph Nodes" value={data.enlargedLymphNodes} options={['No', 'Yes']} onChange={(v) => onChange('enlargedLymphNodes', v)} featureKey="enlargedLymphNodes" />
        <Select label="Distant Metastasis" value={data.distantMetastasis} options={['No', 'Yes']} onChange={(v) => onChange('distantMetastasis', v)} featureKey="distantMetastasis" />
      </InputGroup>

      <div className="flex justify-center pt-12 pb-20">
        <button 
          onClick={onSubmit}
          className="group relative h-20 px-16 rounded-full bg-gradient-to-r from-medical-800 via-medical-600 to-medical-900 text-white font-black text-2xl tracking-widest shadow-[0_0_30px_rgba(2,132,199,0.5)] hover:shadow-[0_0_50px_rgba(14,165,233,0.8)] transition-all transform hover:-translate-y-1 active:scale-95 flex items-center justify-center gap-4 overflow-hidden"
        >
          {/* Futuristic Shimmer Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:animate-[shimmer_2s_infinite]"></div>
          
          <span className="relative z-10">Run AI Analysis</span>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 relative z-10 group-hover:rotate-12 transition-transform" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            <path d="M12 8v4"/>
            <path d="M12 16h.01"/>
          </svg>

          {/* Sci-fi scanning line */}
          <div className="absolute top-0 left-0 w-full h-[2px] bg-medical-400/50 blur-[1px] animate-[scan_3s_infinite] opacity-0 group-hover:opacity-100"></div>
        </button>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes shimmer {
          100% { transform: translateX(100%); }
        }
        @keyframes scan {
          0% { top: 0; }
          50% { top: 100%; }
          100% { top: 0; }
        }
      `}} />
    </div>
  );
};