
import React, { useState } from 'react';
import { PredictionResult, PatientData, FeatureContribution, DiagnosisClass, RiskLevel, GuidelineResult } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';

interface BatchItem {
  data: PatientData;
  result: PredictionResult;
}

interface Props {
  data: PatientData;
  result: PredictionResult;
  batchResults?: BatchItem[] | null;
  onReset: () => void;
  onExportExcel: () => void;
  onExportEncodedExcel: () => void;
  onExportBatchExcel?: () => void;
  onExportBatchEncodedExcel?: () => void;
  onExportBatchPDF?: () => void;
  onExportPDF: () => void;
  onViewCase?: (item: BatchItem) => void;
}

const DIAG_CLASS_COLORS: Record<string, string> = {
  [DiagnosisClass.IPMN]: '#0ea5e9',
  [DiagnosisClass.MCN]: '#f97316',
  [DiagnosisClass.PNET]: '#ef4444',
  [DiagnosisClass.SCN]: '#10b981',
  [DiagnosisClass.SPN]: '#8b5cf6',
};

const RISK_LEVEL_COLORS: Record<string, string> = {
  [RiskLevel.Low]: '#10b981',
  [RiskLevel.Medium]: '#f59e0b',
  [RiskLevel.High]: '#ef4444',
};

const DIAG_CARD_BG: Record<string, string> = {
  [DiagnosisClass.IPMN]: 'bg-medical-700',
  [DiagnosisClass.MCN]: 'bg-orange-600',
  [DiagnosisClass.SCN]: 'bg-emerald-700',
  [DiagnosisClass.PNET]: 'bg-red-700',
  [DiagnosisClass.SPN]: 'bg-violet-700',
};

const SHAPChart = ({ data, title }: { data: FeatureContribution[], title: string }) => {
  const filteredData = data.filter(item => Math.abs(item.value) > 0.0001);
  const chartData = filteredData.map(item => ({
    ...item,
    fill: item.value >= 0 ? '#0284c7' : '#f97316'
  }));
  const chartHeight = Math.max(250, chartData.length * 32);
  return (
    <div className="mt-8 bg-gray-50 p-6 rounded-lg border border-gray-200">
      <h4 className="text-md font-bold text-gray-700 mb-4 flex items-center">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-medical-600" viewBox="0 0 20 20" fill="currentColor">
          <path fillRule="evenodd" d="M3 3a1 1 0 000 2v11a1 1 0 000 2h11a1 1 0 100-2H5V5a1 1 0 100-2H3zm9.707 3.293a1 1 0 010 1.414l-2.414 2.414 2.414 2.414a1 1 0 01-1.414 1.414L9 11.414l-2.293 2.293a1 1 0 01-1.414-1.414l2.414-2.414L5.293 7.414a1 1 0 011.414-1.414L9 8.586l2.293-2.293a1 1 0 011.414 0z" clipRule="evenodd" />
        </svg>
        {title}
      </h4>
      <div style={{ height: `${chartHeight}px` }} className="w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart layout="vertical" data={chartData} margin={{ top: 5, right: 30, left: 10, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#e5e7eb" />
            <XAxis type="number" hide />
            <YAxis dataKey="feature" type="category" width={180} tick={{ fontSize: 10, fontWeight: 600, fill: '#374151' }} interval={0} />
            <Tooltip cursor={{fill: 'rgba(229, 231, 235, 0.4)'}} formatter={(val: number) => [val.toFixed(4), 'Contribution']} labelStyle={{ fontWeight: 'bold' }} />
            <Bar dataKey="value" radius={[0, 4, 4, 0]}>
              {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
      <div className="flex gap-4 mt-2 text-[10px] justify-center tracking-wider font-bold">
        <div className="flex items-center gap-1"><div className="w-3 h-3 rounded-sm bg-[#f97316]"></div><span className="text-gray-500 uppercase">Opposes Prediction</span></div>
        <div className="flex items-center gap-1"><div className="w-3 h-3 rounded-sm bg-[#0284c7]"></div><span className="text-gray-500 uppercase">Supports Prediction</span></div>
      </div>
    </div>
  );
};

const GuidelineCard: React.FC<{ guideline: GuidelineResult }> = ({ guideline }) => {
  const statusColors = {
    'High Risk': { bg: 'bg-red-50', text: 'text-red-800', border: 'border-red-200', square: '#ef4444' },
    'Worrisome': { bg: 'bg-orange-50', text: 'text-orange-800', border: 'border-orange-200', square: '#f59e0b' },
    'Low Risk': { bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', square: '#10b981' }
  };
  const colors = statusColors[guideline.level];
  return (
    <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all">
      <div className="flex justify-between items-start mb-3">
        <h4 className="font-bold text-gray-800 text-sm">{guideline.name}</h4>
        <div className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border ${colors.bg} ${colors.text} ${colors.border}`}>
          <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: colors.square }}></div>
          <span className="text-[10px] font-black tracking-wider uppercase">{guideline.level}</span>
        </div>
      </div>
      <p className="text-xs text-gray-500 mb-4 leading-relaxed italic">"{guideline.evaluationLogic}"</p>
      <div className="space-y-3">
        <div>
          <span className="text-[10px] font-bold text-gray-400 tracking-widest block mb-1">KEY FINDINGS</span>
          <ul className="list-disc list-inside text-xs text-gray-700 space-y-1">{guideline.findings.map((f, i) => <li key={i}>{f}</li>)}</ul>
        </div>
        <div>
          <span className="text-[10px] font-bold text-gray-400 tracking-widest block mb-1 uppercase">Strategy</span>
          <p className="text-xs font-bold text-medical-800 bg-medical-50 p-2 rounded border border-medical-100">{guideline.strategy}</p>
        </div>
      </div>
    </div>
  );
};

export const ResultsView: React.FC<Props> = ({ data, result, batchResults, onReset, onExportExcel, onExportEncodedExcel, onExportBatchExcel, onExportBatchEncodedExcel, onExportBatchPDF, onExportPDF, onViewCase }) => {
  const [activeTab, setActiveTab] = useState<'ai' | 'guidelines'>('ai');

  if (batchResults && batchResults.length > 0) {
    return (
      <div className="max-w-6xl mx-auto space-y-6 animate-in fade-in duration-500">
        <div className="bg-white p-6 rounded-2xl shadow-xl border border-gray-100 flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h2 className="text-2xl font-black text-medical-900 tracking-tight">Batch Analysis Summary</h2>
            <p className="text-gray-500 text-sm font-medium">Successfully processed {batchResults.length} clinical records</p>
          </div>
          <div className="flex flex-wrap gap-3 w-full md:w-auto">
            <button onClick={onExportBatchExcel} className="px-5 py-2.5 bg-emerald-600 text-white rounded-xl font-bold shadow-lg hover:bg-emerald-700 transition-all flex items-center justify-center gap-2">Batch Excel</button>
            <button onClick={onExportBatchEncodedExcel} className="px-5 py-2.5 bg-gray-700 text-white rounded-xl font-bold shadow-lg hover:bg-gray-800 transition-all flex items-center justify-center gap-2">Encoded Excel</button>
            <button onClick={onExportBatchPDF} className="px-5 py-2.5 bg-medical-700 text-white rounded-xl font-bold shadow-lg hover:bg-medical-800 transition-all flex items-center justify-center gap-2">Batch PDFs</button>
            <button onClick={onReset} className="px-6 py-2.5 bg-gray-100 text-gray-600 rounded-xl font-bold hover:bg-gray-200 transition-all">Clear Batch</button>
          </div>
        </div>
        <div className="bg-white rounded-2xl shadow-xl border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="bg-medical-900 text-white text-[10px] font-black tracking-widest uppercase">
                  <th className="px-6 py-4">Case ID</th>
                  <th className="px-6 py-4">Predicted Diagnosis</th>
                  <th className="px-6 py-4">Confidence</th>
                  <th className="px-6 py-4">Risk Stratification</th>
                  <th className="px-6 py-4">Risk Probability</th>
                  <th className="px-6 py-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {batchResults.map((item, idx) => {
                  // FIX: Explicitly cast to number and simplify arithmetic to resolve TS error
                  const diagValue = Number(item.result.diagnosis.probabilities[item.result.diagnosis.class]) || 0;
                  const diagConfidence = (diagValue * 100).toFixed(1);
                  
                  const riskValue = item.result.risk ? (Number(item.result.risk.probabilities[item.result.risk.level]) || 0) : null;
                  const riskConfidence = riskValue !== null ? (riskValue * 100).toFixed(1) : null;

                  return (
                    <tr key={idx} className="hover:bg-medical-50/50 transition-colors group">
                      <td className="px-6 py-4 font-mono font-bold text-medical-800">{item.data.patientId}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-sm shrink-0" style={{ backgroundColor: DIAG_CLASS_COLORS[item.result.diagnosis.class] }}></div>
                          <span className="font-bold text-[11px] text-gray-700 uppercase">{item.result.diagnosis.class}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 font-mono">{diagConfidence}%</td>
                      <td className="px-6 py-4">
                        {item.result.risk ? (
                          <div className="flex items-center gap-2">
                            <div className="w-3 h-3 rounded-sm shrink-0" style={{ backgroundColor: RISK_LEVEL_COLORS[item.result.risk.level] }}></div>
                            <span className="font-bold text-[11px] text-gray-700 uppercase">{item.result.risk.level}</span>
                          </div>
                        ) : <span className="text-gray-300 italic">N/A</span>}
                      </td>
                      <td className="px-6 py-4 font-mono">
                        {riskConfidence !== null ? `${riskConfidence}%` : <span className="text-gray-300 italic">N/A</span>}
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button onClick={() => onViewCase?.(item)} className="p-2 text-medical-600 hover:bg-medical-100 rounded-lg transition-colors inline-flex items-center gap-1 font-bold text-xs uppercase">Details</button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }

  const diagData = Object.entries(result.diagnosis.probabilities)
    .sort((a, b) => (Number(b[1]) || 0) - (Number(a[1]) || 0))
    .map(([key, val]) => ({ name: key, value: Number(val), color: DIAG_CLASS_COLORS[key] || '#94a3b8' }));
  const riskData = result.risk ? Object.entries(result.risk.probabilities)
    .sort((a, b) => (Number(b[1]) || 0) - (Number(a[1]) || 0))
    .map(([key, val]) => ({ name: key, value: Number(val), color: RISK_LEVEL_COLORS[key] || '#94a3b8' })) : [];

  // FIX: Simplified arithmetic for main view calculations
  const mainDiagProbValue = Number(result.diagnosis.probabilities[result.diagnosis.class]) || 0;
  const mainDiagConfidence = (mainDiagProbValue * 100).toFixed(1);
  const mainRiskProbValue = result.risk ? (Number(result.risk.probabilities[result.risk.level]) || 0) : null;
  const mainRiskConfidence = mainRiskProbValue !== null ? (mainRiskProbValue * 100).toFixed(1) : null;

  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-2xl border border-gray-100 animate-in slide-in-from-bottom-4 duration-500">
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-100">
        <div><h2 className="text-3xl font-black text-medical-900 tracking-tight">Analysis Report</h2><p className="text-sm text-gray-500 font-medium">PCL-SIRS | Case: {data.patientId || 'UNCATEGORIZED'}</p></div>
        <div className="flex bg-gray-100 p-1 rounded-xl">
          <button onClick={() => setActiveTab('ai')} className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'ai' ? 'bg-white shadow-sm text-medical-700' : 'text-gray-500 hover:text-gray-700'}`}>AI Analysis</button>
          <button onClick={() => setActiveTab('guidelines')} className={`px-4 py-2 text-xs font-bold rounded-lg transition-all ${activeTab === 'guidelines' ? 'bg-white shadow-sm text-medical-700' : 'text-gray-500 hover:text-gray-700'}`}>Guidelines</button>
        </div>
      </div>
      {activeTab === 'ai' ? (
        <div className="space-y-12">
          <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex flex-wrap gap-6 items-center justify-center">
            <span className="text-[10px] font-black text-gray-400 tracking-widest uppercase">Color Legend:</span>
            {Object.entries(DIAG_CLASS_COLORS).map(([name, color]) => (<div key={name} className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm shadow-sm" style={{ backgroundColor: color }}></div><span className="text-[10px] font-bold text-gray-600 uppercase">{name}</span></div>))}
          </div>
          <div className={`${DIAG_CARD_BG[result.diagnosis.class] || 'bg-medical-800'} text-white p-8 rounded-2xl shadow-lg relative overflow-hidden group`}>
            <div className="absolute top-4 right-4 w-6 h-6 rounded-md bg-white/20 border border-white/40 flex items-center justify-center"><div className="w-3 h-3 rounded-sm bg-white"></div></div>
            <h3 className="text-white/70 text-xs font-black tracking-[0.2em] mb-3 uppercase">Diagnostic Classification</h3>
            <div className="text-5xl font-black mb-4 uppercase">{result.diagnosis.class}</div>
            <div className="flex items-center gap-2"><div className="flex-grow h-2 bg-white/20 rounded-full overflow-hidden"><div className="h-full bg-white/80 rounded-full transition-all duration-1000" style={{ width: `${mainDiagProbValue * 100}%` }}></div></div><span className="text-sm font-mono text-white/80">{mainDiagConfidence}% Confidence</span></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="h-64 relative">
              <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none"><span className="text-3xl font-black text-gray-900">{(mainDiagProbValue * 100).toFixed(0)}%</span><span className="text-[9px] font-black text-gray-400 tracking-[0.2em] uppercase mt-1">Confidence</span></div>
              <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={diagData} cx="50%" cy="50%" innerRadius={75} outerRadius={100} paddingAngle={0} dataKey="value" stroke="none" animationDuration={1200} animationBegin={200}>{diagData.map((entry, index) => <Cell key={index} fill={entry.color} />)}</Pie><Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', fontSize: '12px' }} formatter={(val: number) => [`${(Number(val) * 100).toFixed(2)}%`, 'Prob.']} /></PieChart></ResponsiveContainer>
            </div>
            <div className="space-y-4">
              <h4 className="text-[10px] font-black text-gray-400 tracking-widest border-b pb-2 uppercase">Probability Distribution</h4>
              {diagData.map((item, idx) => (
                <div key={item.name} className="flex flex-col">
                  <div className="flex justify-between items-center text-xs mb-1.5"><div className="flex items-center gap-2.5"><div className="w-4 h-4 rounded-sm shadow-sm shrink-0" style={{ backgroundColor: item.color }}></div><span className="font-black text-gray-700 uppercase tracking-tight">{item.name}</span></div><span className="text-medical-600 font-mono font-bold">{(item.value * 100).toFixed(1)}%</span></div>
                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden"><div className="h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${item.value * 100}%`, backgroundColor: item.color }} /></div>
                </div>
              ))}
            </div>
          </div>
          <SHAPChart data={result.diagnosis.contributions} title="DIAGNOSTIC DRIVERS (SHAP ANALYSIS)" />
          {result.risk && mainRiskProbValue !== null && (
            <div className="border-t border-gray-100 pt-12 space-y-12">
               <div className="bg-gray-50 p-4 rounded-xl border border-gray-100 flex flex-wrap gap-6 items-center justify-center">
                <span className="text-[10px] font-black text-gray-400 tracking-widest uppercase">Risk Legend:</span>
                {Object.entries(RISK_LEVEL_COLORS).map(([name, color]) => (<div key={name} className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm shadow-sm" style={{ backgroundColor: color }}></div><span className="text-[10px] font-bold text-gray-600 uppercase">{name}</span></div>))}
              </div>
              <div className="p-8 rounded-2xl shadow-lg relative overflow-hidden group text-white" style={{ backgroundColor: RISK_LEVEL_COLORS[result.risk.level] }}>
                <div className="absolute top-4 right-4 w-6 h-6 rounded-md bg-white/20 border border-white/40 flex items-center justify-center"><div className="w-3 h-3 rounded-sm bg-white"></div></div>
                <h3 className="text-white/70 text-xs font-black tracking-[0.2em] mb-3 uppercase">{result.risk.modelName}</h3>
                <div className="text-5xl font-black mb-4 uppercase">{result.risk.level}</div>
                <div className="flex items-center gap-2"><div className="flex-grow h-2 bg-white/20 rounded-full overflow-hidden"><div className="h-full bg-white/80 rounded-full transition-all duration-1000" style={{ width: `${mainRiskProbValue * 100}%` }}></div></div><span className="text-sm font-mono text-white/80">{mainRiskConfidence}% Probability</span></div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="h-64 relative">
                  <div className="absolute inset-0 flex items-center justify-center flex-col pointer-events-none"><span className="text-3xl font-black text-gray-900">{(mainRiskProbValue * 100).toFixed(0)}%</span><span className="text-[9px] font-black text-gray-400 tracking-[0.2em] uppercase mt-1">Risk Prob.</span></div>
                  <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={riskData} cx="50%" cy="50%" innerRadius={75} outerRadius={100} paddingAngle={0} dataKey="value" stroke="none" animationDuration={1200} animationBegin={200}>{riskData.map((entry, index) => <Cell key={index} fill={entry.color} />)}</Pie><Tooltip contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)', fontSize: '12px' }} formatter={(val: number) => [`${(Number(val) * 100).toFixed(2)}%`, 'Prob.']} /></PieChart></ResponsiveContainer>
                </div>
                <div className="space-y-4">
                  <h4 className="text-[10px] font-black text-gray-400 tracking-widest border-b pb-2 uppercase">Risk Distribution</h4>
                  {riskData.map((item, idx) => (
                    <div key={item.name} className="flex flex-col">
                      <div className="flex justify-between items-center text-xs mb-1.5"><div className="flex items-center gap-2.5"><div className="w-4 h-4 rounded-sm shadow-sm shrink-0" style={{ backgroundColor: item.color }}></div><span className="font-black text-gray-700 uppercase tracking-tight">{item.name}</span></div><span className="text-medical-600 font-mono font-bold">{(item.value * 100).toFixed(1)}%</span></div>
                      <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden"><div className="h-full rounded-full transition-all duration-1000 ease-out" style={{ width: `${item.value * 100}%`, backgroundColor: item.color }} /></div>
                    </div>
                  ))}
                </div>
              </div>
              <SHAPChart data={result.risk.contributions} title="RISK FACTOR WEIGHTINGS (SHAP ANALYSIS)" />
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="bg-medical-50 p-6 rounded-2xl border border-medical-100"><h3 className="text-medical-900 font-bold mb-2 flex items-center gap-2"><svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" /></svg>Clinical Guidelines Consensus</h3><p className="text-sm text-medical-700 leading-relaxed">Standard clinical heuristic rules based on international consensus (Kyoto, European, HK, ACG).</p></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">{result.guidelines?.map((g, idx) => (<GuidelineCard key={idx} guideline={g} />))}</div>
        </div>
      )}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-10 border-t border-gray-100 mt-12">
        <button onClick={onReset} className="px-8 py-3.5 text-medical-700 bg-medical-50 border border-medical-200 hover:bg-medical-100 rounded-xl transition-all font-bold flex items-center gap-2 shadow-sm uppercase text-xs tracking-wider">New Case</button>
        <div className="flex flex-wrap gap-4">
          <button onClick={onExportExcel} className="px-6 py-3.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 shadow-xl transition-all flex items-center gap-2 font-bold uppercase text-xs tracking-wider">Excel</button>
          <button onClick={onExportEncodedExcel} className="px-6 py-3.5 bg-gray-700 text-white rounded-xl hover:bg-gray-800 shadow-xl transition-all flex items-center gap-2 font-bold uppercase text-xs tracking-wider">Encoded Excel</button>
          <button onClick={onExportPDF} className="px-6 py-3.5 bg-medical-700 text-white rounded-xl hover:bg-medical-800 shadow-xl transition-all flex items-center gap-2 font-bold uppercase text-xs tracking-wider">PDF</button>
        </div>
      </div>
    </div>
  );
};
